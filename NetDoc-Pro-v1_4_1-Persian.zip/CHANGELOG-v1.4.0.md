# NetDoc Pro v1.4.0

- Added a login screen before the application dashboard.
- Initial account: username `admin`, password `admin`.
- Added right-sidebar user management for administrators.
- Administrators can add, edit, and delete users.
- Roles: administrator, standard user, and read-only viewer.
- Prevents deleting the currently signed-in account and the last administrator.

Security note: this application currently runs locally in the browser. Authentication and user records are stored in browser storage and are not equivalent to server-side authentication. Change the initial password immediately and do not expose this offline app as a public service.
