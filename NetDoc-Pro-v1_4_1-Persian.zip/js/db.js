/**
 * NetDoc Pro Data Access Layer (Simulated Repository over LocalStorage)
 */
const DB = {
    KEYS: {
        COMPANIES: 'netdoc_companies',
        DEVICE_TYPES: 'netdoc_device_types',
        DEVICES: 'netdoc_devices'
    },

    init() {
        if (!localStorage.getItem(this.KEYS.COMPANIES)) {
            const defaultCompanies = [
                { id: 'c1', name: 'Factory FX', location: 'اصفهان - شهرک صنعتی', description: 'پروژه مستندسازی شبکه کارخانه اصلی', updatedAt: new Date().toISOString() },
                { id: 'c2', name: 'Company Z', location: 'تهران - دفتر مرکزی', description: 'تجهیزات اتاق سرور مرکزی', updatedAt: new Date().toISOString() }
            ];
            localStorage.setItem(this.KEYS.COMPANIES, JSON.stringify(defaultCompanies));
        }

        const defaultTypes = [
            { id: 't1', name: 'Cisco Switch', category: 'switch', icon: 'switch' },
            { id: 't2', name: 'Cisco Router', category: 'router', icon: 'router' },
            { id: 't3', name: 'MikroTik Router', category: 'router', icon: 'router' },
            { id: 't4', name: 'Server', category: 'server', icon: 'server' },
            { id: 't5', name: 'Virtual Machine', category: 'vm', icon: 'vm' },
            { id: 't6', name: 'Firewall', category: 'firewall', icon: 'firewall' },
            { id: 't7', name: 'Access Point', category: 'ap', icon: 'ap' },
            { id: 't8', name: 'Wireless Controller', category: 'controller', icon: 'controller' },
            { id: 't9', name: 'Core Switch', category: 'switch', icon: 'switch' },
            { id: 't10', name: 'Distribution Switch', category: 'switch', icon: 'switch' },
            { id: 't11', name: 'Load Balancer', category: 'loadbalancer', icon: 'loadbalancer' },
            { id: 't12', name: 'VPN Gateway', category: 'router', icon: 'vpn' },
            { id: 't13', name: 'Proxy Server', category: 'server', icon: 'proxy' },
            { id: 't14', name: 'IDS / IPS', category: 'security', icon: 'security' },
            { id: 't15', name: 'NAS / Storage', category: 'nas', icon: 'nas' },
            { id: 't16', name: 'Modem / ONT', category: 'modem', icon: 'modem' },
            { id: 't17', name: 'VoIP / IP Phone', category: 'phone', icon: 'phone' },
            { id: 't18', name: 'DVR / NVR', category: 'camera', icon: 'camera' },
            { id: 't19', name: 'UPS / Power', category: 'power', icon: 'power' },
            { id: 't20', name: 'Printer', category: 'printer', icon: 'printer' },
            { id: 't21', name: 'Other', category: 'other', icon: 'other' }
        ];

        let storedTypes = this.getDeviceTypes();
        if (!storedTypes.length) {
            localStorage.setItem(this.KEYS.DEVICE_TYPES, JSON.stringify(defaultTypes));
        } else {
            const existingIds = new Set(storedTypes.map(t => t.id));
            const missing = defaultTypes.filter(t => !existingIds.has(t.id));
            if (missing.length) {
                storedTypes = storedTypes.concat(missing);
                localStorage.setItem(this.KEYS.DEVICE_TYPES, JSON.stringify(storedTypes));
            }
        }

        if (!localStorage.getItem(this.KEYS.DEVICES)) {
            const defaultDevices = [
                {
                    id: 'd1',
                    companyId: 'c1',
                    deviceTypeId: 't1',
                    name: 'Cisco-Core-SW',
                    hostname: 'sw-core-factory.local',
                    brand: 'Cisco',
                    model: 'Catalyst 2960X',
                    rack: 'Rack A - U10',
                    managementIp: '192.168.10.2',
                    subnetMask: '255.255.255.0',
                    gateway: '192.168.10.1',
                    macAddress: '00:25:B2:11:22:33',
                    firmwareVersion: '15.2(4)E2',
                    services: 'SSH, HTTPS, SNMP',
                    vlans: [
                        { id: 10, name: 'Management', net: '192.168.10.0/24', gw: '192.168.10.1' },
                        { id: 20, name: 'Users', net: '192.168.20.0/24', gw: '192.168.20.1' }
                    ],
                    users: [
                        { username: 'admin', password: 'Password123!', role: 'Administrator', notes: 'دسترسی کامل' }
                    ],
                    notes: 'سوئیچ اصلی Core کارخانه',
                    createdAt: new Date().toISOString()
                },
                {
                    id: 'd2',
                    companyId: 'c1',
                    deviceTypeId: 't3',
                    name: 'MikroTik-Main-GW',
                    hostname: 'mt-factory-gw',
                    brand: 'MikroTik',
                    model: 'CCR1009-7G-1C-1S+',
                    managementIp: '192.168.10.1',
                    firmwareVersion: 'RouterOS 7.11',
                    mtIdentity: 'Factory-Gateway',
                    mtInterfaces: 'ether1 (WAN), ether2 (LAN), sfp1 (Fiber)',
                    mtIpAddresses: '192.168.10.1/24, 185.10.10.2/30',
                    mtBridges: 'bridge-lan',
                    mtVlans: 'VLAN10, VLAN20',
                    mtDhcpServer: 'dhcp1 (192.168.20.10-100)',
                    mtNat: 'srcnat masquerade WAN',
                    mtFirewall: 'Input Drop default, Fasttrack enabled',
                    mtVpn: 'L2TP IPsec Server Enabled',
                    mtDnsNtp: 'DNS: 8.8.8.8, NTP: pool.ntp.org',
                    users: [
                        { username: 'netadmin', password: 'MikroTikPass!#', role: 'Full Admin', notes: 'WinBox' }
                    ],
                    createdAt: new Date().toISOString()
                }
            ];
            localStorage.setItem(this.KEYS.DEVICES, JSON.stringify(defaultDevices));
        }
    },

    resetToDefaults() {
        localStorage.removeItem(this.KEYS.COMPANIES);
        localStorage.removeItem(this.KEYS.DEVICE_TYPES);
        localStorage.removeItem(this.KEYS.DEVICES);
        this.init();
    },

    getCompanies() {
        return JSON.parse(localStorage.getItem(this.KEYS.COMPANIES) || '[]');
    },

    saveCompany(company) {
        const companies = this.getCompanies();
        company.id = 'c_' + Date.now();
        company.updatedAt = new Date().toISOString();
        companies.push(company);
        localStorage.setItem(this.KEYS.COMPANIES, JSON.stringify(companies));
        return company;
    },

    updateCompany(company) {
        const companies = this.getCompanies();
        const index = companies.findIndex(c => c.id === company.id);
        if (index === -1) return null;
        companies[index] = { ...companies[index], ...company, updatedAt: new Date().toISOString() };
        localStorage.setItem(this.KEYS.COMPANIES, JSON.stringify(companies));
        return companies[index];
    },

    deleteCompany(id) {
        if (!id) return { deleted: false, devicesRemoved: 0 };
        const companies = this.getCompanies();
        const exists = companies.some(c => c.id === id);
        if (!exists) return { deleted: false, devicesRemoved: 0 };

        const devices = this.getDevices();
        const remainingDevices = devices.filter(d => d.companyId !== id);
        const devicesRemoved = devices.length - remainingDevices.length;

        localStorage.setItem(this.KEYS.COMPANIES, JSON.stringify(companies.filter(c => c.id !== id)));
        localStorage.setItem(this.KEYS.DEVICES, JSON.stringify(remainingDevices));
        return { deleted: true, devicesRemoved };
    },

    getDeviceTypes() {
        return JSON.parse(localStorage.getItem(this.KEYS.DEVICE_TYPES) || '[]');
    },

    saveDeviceType(type) {
        const types = this.getDeviceTypes();
        type.id = 'dt_' + Date.now();
        types.push(type);
        localStorage.setItem(this.KEYS.DEVICE_TYPES, JSON.stringify(types));
        return type;
    },

    getDevices() {
        return JSON.parse(localStorage.getItem(this.KEYS.DEVICES) || '[]');
    },

    saveDevice(device) {
        const devices = this.getDevices();
        if (device.id) {
            const index = devices.findIndex(d => d.id === device.id);
            if (index !== -1) {
                devices[index] = { ...devices[index], ...device, updatedAt: new Date().toISOString() };
            }
        } else {
            device.id = 'd_' + Date.now();
            device.createdAt = new Date().toISOString();
            devices.push(device);
        }
        localStorage.setItem(this.KEYS.DEVICES, JSON.stringify(devices));
        
        // Update company modified date
        const companies = this.getCompanies();
        const comp = companies.find(c => c.id === device.companyId);
        if (comp) {
            comp.updatedAt = new Date().toISOString();
            localStorage.setItem(this.KEYS.COMPANIES, JSON.stringify(companies));
        }
        return device;
    },

    deleteDevice(id) {
        let devices = this.getDevices();
        devices = devices.filter(d => d.id !== id);
        localStorage.setItem(this.KEYS.DEVICES, JSON.stringify(devices));
    },

    exportAll() {
        return {
            app: 'NetDoc Pro',
            format: 'netdoc-full-backup',
            version: '1.3.2',
            exportedAt: new Date().toISOString(),
            data: {
                companies: this.getCompanies(),
                deviceTypes: this.getDeviceTypes(),
                devices: this.getDevices()
            }
        };
    },

    validateImport(payload) {
        if (!payload || payload.format !== 'netdoc-full-backup' || !payload.data) {
            throw new Error('فرمت فایل پشتیبان NetDoc Pro معتبر نیست.');
        }
        const { companies, deviceTypes, devices } = payload.data;
        if (!Array.isArray(companies) || !Array.isArray(deviceTypes) || !Array.isArray(devices)) {
            throw new Error('ساختار فایل پشتیبان ناقص است.');
        }
        const companyIds = new Set(companies.map(c => c && c.id).filter(Boolean));
        const typeIds = new Set(deviceTypes.map(t => t && t.id).filter(Boolean));
        if (companies.some(c => !c || !c.id || !c.name)) throw new Error('اطلاعات مجموعه‌ها معتبر نیست.');
        if (deviceTypes.some(t => !t || !t.id || !t.name)) throw new Error('اطلاعات انواع تجهیزات معتبر نیست.');
        if (devices.some(d => !d || !d.id || !d.companyId || !d.deviceTypeId || !d.name)) {
            throw new Error('اطلاعات تجهیزات معتبر نیست.');
        }
        if (devices.some(d => !companyIds.has(d.companyId))) throw new Error('یک یا چند تجهیز به مجموعه نامعتبر متصل است.');
        if (devices.some(d => !typeIds.has(d.deviceTypeId))) throw new Error('یک یا چند تجهیز به نوع تجهیز نامعتبر متصل است.');
        return true;
    },

    importAll(payload) {
        this.validateImport(payload);
        const { companies = [], deviceTypes = [], devices = [] } = payload.data;
        const currentCompanies = this.getCompanies();
        const currentTypes = this.getDeviceTypes();
        const currentDevices = this.getDevices();

        // Merge by human-readable names instead of IDs. Matching companies are replaced
        // (including their devices); companies that do not exist are added.
        const companyMap = new Map(currentCompanies.map(c => [String(c.name || '').trim().toLowerCase(), c]));
        const typeMap = new Map(currentTypes.map(t => [String(t.name || '').trim().toLowerCase(), t]));
        const importedCompanyIdMap = new Map();
        const importedTypeIdMap = new Map();
        const replacedCompanyIds = new Set();
        const now = new Date().toISOString();

        const mergedCompanies = [...currentCompanies];
        companies.forEach((incoming) => {
            const key = String(incoming.name || '').trim().toLowerCase();
            const existing = companyMap.get(key);
            const newId = existing ? existing.id : ('c_' + Date.now() + '_' + Math.random().toString(36).slice(2, 8));
            const merged = { ...incoming, id: newId, updatedAt: now };
            importedCompanyIdMap.set(incoming.id, newId);
            if (existing) {
                const idx = mergedCompanies.findIndex(c => c.id === existing.id);
                mergedCompanies[idx] = merged;
                replacedCompanyIds.add(existing.id);
            } else {
                mergedCompanies.push(merged);
                companyMap.set(key, merged);
            }
        });

        const mergedTypes = [...currentTypes];
        deviceTypes.forEach((incoming) => {
            const key = String(incoming.name || '').trim().toLowerCase();
            const existing = typeMap.get(key);
            const newId = existing ? existing.id : ('dt_' + Date.now() + '_' + Math.random().toString(36).slice(2, 8));
            const merged = { ...incoming, id: newId };
            importedTypeIdMap.set(incoming.id, newId);
            if (existing) {
                const idx = mergedTypes.findIndex(t => t.id === existing.id);
                mergedTypes[idx] = merged;
            } else {
                mergedTypes.push(merged);
                typeMap.set(key, merged);
            }
        });

        // Remove devices belonging to companies that are being replaced, then append
        // imported devices with remapped company/type IDs.
        const keptDevices = currentDevices.filter(d => !replacedCompanyIds.has(d.companyId));
        const importedDevices = devices.map(d => ({
            ...d,
            id: 'd_' + Date.now() + '_' + Math.random().toString(36).slice(2, 9),
            companyId: importedCompanyIdMap.get(d.companyId) || d.companyId,
            deviceTypeId: importedTypeIdMap.get(d.deviceTypeId) || d.deviceTypeId,
            updatedAt: now
        }));

        localStorage.setItem(this.KEYS.COMPANIES, JSON.stringify(mergedCompanies));
        localStorage.setItem(this.KEYS.DEVICE_TYPES, JSON.stringify(mergedTypes));
        localStorage.setItem(this.KEYS.DEVICES, JSON.stringify([...keptDevices, ...importedDevices]));
        return {
            companies: companies.length,
            addedCompanies: companies.filter(c => !currentCompanies.some(x => String(x.name||'').trim().toLowerCase() === String(c.name||'').trim().toLowerCase())).length,
            replacedCompanies: companies.length - companies.filter(c => !currentCompanies.some(x => String(x.name||'').trim().toLowerCase() === String(c.name||'').trim().toLowerCase())).length,
            deviceTypes: deviceTypes.length,
            devices: devices.length
        };
    },

    importSingleCompany(company, devices, deviceTypes = []) {
        if (!company || !company.name) throw new Error('اطلاعات مجموعه در فایل HTML پیدا نشد.');
        const payload = {
            app: 'NetDoc Pro',
            format: 'netdoc-full-backup',
            version: '1.3.3',
            exportedAt: new Date().toISOString(),
            data: { companies: [company], deviceTypes, devices }
        };
        this.validateImport(payload);
        return this.importAll(payload);
    }
};

DB.init();
