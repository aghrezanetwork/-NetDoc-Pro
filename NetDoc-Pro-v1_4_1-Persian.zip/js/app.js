// Storage keys must be initialized before DOMContentLoaded callbacks run.
const APP_USERS_KEY = 'netdoc_app_users';
const APP_SESSION_KEY = 'netdoc_app_session';

document.addEventListener('DOMContentLoaded', () => {
    initAuthentication();
    initUserManagement();


    initNavigation();
    initForms();
    initPasswordToggles();
    initNetworkValidation();
    initPortValidation();
    initCompanyLinks();
    renderDashboard();
    populateSelects();

    // Some existing localStorage data is normalized while the form controls
    // initialize. Render the dashboard once more on the next frame so the
    // full collection-and-device cards are present on the first page load.
    requestAnimationFrame(() => renderDashboard());

    // -------------------------------------------------------------
    // Routing & Navigation
    // -------------------------------------------------------------
    
// Local/offline sign-in and user administration.
// This client-side gate is suitable for a local single-browser app, not server security.
function getAppUsers() {
    try { return JSON.parse(localStorage.getItem(APP_USERS_KEY) || '[]'); }
    catch (_) { return []; }
}
function saveAppUsers(users) { localStorage.setItem(APP_USERS_KEY, JSON.stringify(users)); }
function getActiveAppUser() {
    const username = sessionStorage.getItem(APP_SESSION_KEY);
    return getAppUsers().find(user => user.username === username) || null;
}
function initAuthentication() {
    let users = getAppUsers();
    if (!users.length) {
        users = [{ id: 'initial-admin', fullName: 'مدیر سیستم', username: 'm', password: 'admin', role: 'admin' }];
        saveAppUsers(users);
    }
    const screen = document.getElementById('loginScreen');
    const form = document.getElementById('loginForm');
    const appRoot = document.querySelector('.app-container');
    const error = document.getElementById('loginError');
    const showApp = user => {
        document.body.classList.remove('auth-locked');
        screen.style.display = 'none';
        appRoot.style.display = '';
        document.getElementById('currentUserLabel').textContent = user.fullName || user.username;
        const usersNav = document.getElementById('usersNavItem');
        if (usersNav) usersNav.style.display = user.role === 'admin' ? '' : 'none';
    };
    const active = getActiveAppUser();
    if (active) showApp(active);
    else {
        document.body.classList.add('auth-locked');
        appRoot.style.display = 'none';
        screen.style.display = 'flex';
    }
    form.addEventListener('submit', event => {
        event.preventDefault();
        const username = document.getElementById('loginUsername').value.trim();
        const password = document.getElementById('loginPassword').value;
        const user = getAppUsers().find(item => item.username.toLowerCase() === username.toLowerCase() && item.password === password);
        if (!user) { error.textContent = 'نام کاربری یا رمز عبور اشتباه است.'; return; }
        sessionStorage.setItem(APP_SESSION_KEY, user.username);
        form.reset();
        error.textContent = '';
        showApp(user);
    });
    document.getElementById('logoutBtn').addEventListener('click', () => {
        sessionStorage.removeItem(APP_SESSION_KEY);
        document.body.classList.add('auth-locked');
        appRoot.style.display = 'none';
        screen.style.display = 'flex';
        document.getElementById('loginPassword').value = '';
    });
}
function initUserManagement() {
    const form = document.getElementById('appUserForm');
    if (!form) return;
    const notice = document.getElementById('userManagementNotice');
    const reset = () => {
        form.reset();
        document.getElementById('appUserId').value = '';
        document.getElementById('userFormTitle').textContent = 'افزودن کاربر جدید';
        document.getElementById('appUserPassword').required = true;
        document.getElementById('passwordOptionalHint').textContent = '(برای کاربر جدید الزامی)';
        document.getElementById('saveAppUserBtn').textContent = 'ذخیره کاربر';
    };
    document.getElementById('cancelAppUserEditBtn').addEventListener('click', reset);
    form.addEventListener('submit', event => {
        event.preventDefault();
        const active = getActiveAppUser();
        if (!active || active.role !== 'admin') { notice.textContent = 'دسترسی غیرمجاز.'; return; }
        const id = document.getElementById('appUserId').value;
        const fullName = document.getElementById('appUserFullName').value.trim();
        const username = document.getElementById('appUsername').value.trim();
        const password = document.getElementById('appUserPassword').value;
        const role = document.getElementById('appUserRole').value;
        const users = getAppUsers();
        if (!/^[a-zA-Z0-9._-]{3,32}$/.test(username)) { notice.textContent = 'نام کاربری باید ۳ تا ۳۲ کاراکتر و شامل حروف انگلیسی، عدد، نقطه، خط تیره یا زیرخط باشد.'; return; }
        if (!id && password.length < 4) { notice.textContent = 'رمز عبور کاربر جدید باید حداقل ۴ کاراکتر باشد.'; return; }
        if (users.some(user => user.username.toLowerCase() === username.toLowerCase() && user.id !== id)) { notice.textContent = 'این نام کاربری قبلاً ثبت شده است.'; return; }
        if (id) {
            const index = users.findIndex(user => user.id === id);
            if (index < 0) return;
            const oldUsername = users[index].username;
            users[index] = { ...users[index], fullName, username, role, ...(password ? { password } : {}) };
            if (active.username === oldUsername) {
                sessionStorage.setItem(APP_SESSION_KEY, username);
                document.getElementById('currentUserLabel').textContent = fullName || username;
            }
            notice.textContent = 'اطلاعات کاربر ویرایش شد.';
        } else {
            users.push({ id: 'user-' + Date.now(), fullName, username, password, role });
            notice.textContent = 'کاربر جدید اضافه شد.';
        }
        saveAppUsers(users);
        reset();
        renderAppUsers();
    });
    document.getElementById('appUsersTableBody').addEventListener('click', event => {
        const button = event.target.closest('button[data-action]');
        if (!button) return;
        const active = getActiveAppUser();
        if (!active || active.role !== 'admin') return;
        const users = getAppUsers();
        const target = users.find(user => user.id === button.dataset.id);
        if (!target) return;
        if (button.dataset.action === 'edit') {
            document.getElementById('appUserId').value = target.id;
            document.getElementById('appUserFullName').value = target.fullName || '';
            document.getElementById('appUsername').value = target.username;
            document.getElementById('appUserPassword').value = '';
            document.getElementById('appUserPassword').required = false;
            document.getElementById('passwordOptionalHint').textContent = '(برای تغییر رمز، مقدار جدید وارد کنید)';
            document.getElementById('appUserRole').value = target.role;
            document.getElementById('userFormTitle').textContent = 'ویرایش کاربر';
            document.getElementById('saveAppUserBtn').textContent = 'ذخیره تغییرات';
            document.getElementById('appUserFullName').focus();
        } else if (button.dataset.action === 'delete') {
            if (target.username === active.username) { alert('نمی‌توانید حساب فعلی خودتان را حذف کنید.'); return; }
            if (target.role === 'admin' && users.filter(user => user.role === 'admin').length <= 1) { alert('حداقل یک مدیر سیستم باید باقی بماند.'); return; }
            if (!confirm(`کاربر «${target.fullName || target.username}» حذف شود؟`)) return;
            saveAppUsers(users.filter(user => user.id !== target.id));
            notice.textContent = 'کاربر حذف شد.';
            renderAppUsers();
        }
    });
}
function renderAppUsers() {
    const tbody = document.getElementById('appUsersTableBody');
    if (!tbody) return;
    const active = getActiveAppUser();
    if (!active || active.role !== 'admin') { tbody.innerHTML = '<tr><td colspan="4">دسترسی مجاز نیست.</td></tr>'; return; }
    const roleNames = { admin: 'مدیر سیستم', user: 'کاربر', viewer: 'فقط مشاهده' };
    tbody.innerHTML = getAppUsers().map(user => `
        <tr><td>${esc(user.fullName || '-')}</td><td>${esc(user.username)}</td><td>${roleNames[user.role] || 'کاربر'}</td>
        <td class="user-actions"><button type="button" class="btn btn-secondary" data-action="edit" data-id="${esc(user.id)}">ویرایش</button>
        <button type="button" class="btn btn-danger" data-action="delete" data-id="${esc(user.id)}">حذف</button></td></tr>`).join('');
}

function initNavigation() {
        const navItems = document.querySelectorAll('.nav-item');
        navItems.forEach(item => {
            item.addEventListener('click', (e) => {
                e.preventDefault();
                const target = item.getAttribute('data-target');
                const activeAppUser = getActiveAppUser();
                if (target === 'users' && (!activeAppUser || activeAppUser.role !== 'admin')) {
                    alert('فقط مدیر سیستم به مدیریت کاربران دسترسی دارد.');
                    return;
                }


                navItems.forEach(i => i.classList.remove('active'));
                item.classList.add('active');

                document.querySelectorAll('.view-section').forEach(sec => sec.classList.remove('active'));
                document.getElementById(target).classList.add('active');

                if (target === 'dashboard') renderDashboard();
                if (target === 'edit') populateEditSelects();
                if (target === 'users') renderAppUsers();
                if (target === 'export') renderExportOptions();
            });
        });

        const tabBtns = document.querySelectorAll('.tab-btn');
        tabBtns.forEach(btn => {
            btn.addEventListener('click', () => {
                const targetTab = btn.getAttribute('data-tab');
                tabBtns.forEach(b => b.classList.remove('active'));
                btn.classList.add('active');

                document.querySelectorAll('.tab-content').forEach(tc => tc.classList.remove('active'));
                document.getElementById(targetTab).classList.add('active');
            });
        });

        // Search Input
        document.getElementById('globalSearch').addEventListener('input', (e) => {
            const query = e.target.value.trim().toLowerCase();
            if (query.length > 0) {
                // Search results are displayed in the dashboard collection list.
                document.querySelector('[data-target="dashboard"]').click();
                renderCollectionsList(query);
            } else {
                renderDashboard();
            }
        });
    }

    // -------------------------------------------------------------
    // Password visibility controls
    // -------------------------------------------------------------
    function initPasswordToggles() {
        document.addEventListener('click', (e) => {
            const button = e.target.closest('.toggle-password');
            if (!button) return;
            const field = button.parentElement && button.parentElement.querySelector('.user-password');
            if (!field) return;

            const isVisible = field.type === 'text';
            field.type = isVisible ? 'password' : 'text';
            button.setAttribute('aria-pressed', String(!isVisible));
            button.title = isVisible ? 'نمایش رمز عبور' : 'مخفی کردن رمز عبور';
            button.setAttribute('aria-label', button.title);
            button.classList.toggle('is-visible', !isVisible);
        });
    }

    // -------------------------------------------------------------
    // Populate Dropdowns
    // -------------------------------------------------------------
    function populateSelects() {
        const companySelect = document.getElementById('deviceCompanySelect');
        const exportCompanySelect = document.getElementById('exportCompanySelect');
        const companies = DB.getCompanies();

        companySelect.innerHTML = '<option value="">انتخاب کنید...</option>';
        exportCompanySelect.innerHTML = '<option value="">انتخاب کنید...</option>';

        companies.forEach(c => {
            companySelect.innerHTML += `<option value="${c.id}">${c.name}</option>`;
            exportCompanySelect.innerHTML += `<option value="${c.id}">${c.name}</option>`;
        });

        const typeSelect = document.getElementById('deviceTypeSelect');
        const types = DB.getDeviceTypes();

        typeSelect.innerHTML = '<option value="">انتخاب کنید...</option><option value="__NEW__">＋ افزودن نوع تجهیز جدید...</option>';
        types.forEach(t => {
            typeSelect.innerHTML += `<option value="${esc(t.id)}">${typeEmoji(t)} ${esc(t.name)}</option>`;
        });
    }

    // -------------------------------------------------------------
    // Dynamic Fields rendering based on Device Type
    // -------------------------------------------------------------
    function esc(value) {
        return String(value ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/\"/g, '&quot;').replace(/'/g, '&#039;');
    }

    const TYPE_ICON_PATHS = {
        building: '<path d="M4 21V5a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v16M8 7h2M8 11h2M8 15h2M13 7h2M13 11h2M13 15h2M18 9h2v12"/><path d="M2 21h20"/>',
        switch: '<rect x="4" y="7" width="16" height="10" rx="2"/><path d="M7 10h2M11 10h2M15 10h2M7 14h2M11 14h2M15 14h2"/>',
        router: '<path d="M4 9h16M6 9l3-4 3 4 3-4 3 4"/><path d="M5 15h14"/><circle cx="8" cy="18" r="1"/><circle cx="12" cy="18" r="1"/><circle cx="16" cy="18" r="1"/>',
        server: '<rect x="4" y="4" width="16" height="6" rx="1.5"/><rect x="4" y="14" width="16" height="6" rx="1.5"/><path d="M7 7h.01M7 17h.01M10 7h7M10 17h7"/>',
        vm: '<rect x="5" y="5" width="14" height="14" rx="2"/><path d="M9 2v3M15 2v3M9 19v3M15 19v3M2 9h3M2 15h3M19 9h3M19 15h3"/><path d="M9 12h6M12 9v6"/>',
        firewall: '<path d="M12 3l8 3v5c0 5-3.5 8.5-8 10-4.5-1.5-8-5-8-10V6l8-3z"/><path d="M8 10h8M8 14h8M12 6v12"/>',
        ap: '<path d="M4 10a10 10 0 0 1 16 0M7 13a6 6 0 0 1 10 0M10 16a2.5 2.5 0 0 1 4 0"/><circle cx="12" cy="19" r="1"/>',
        controller: '<circle cx="12" cy="12" r="3"/><path d="M4 9a9 9 0 0 1 16 0M4 15a9 9 0 0 0 16 0"/>',
        loadbalancer: '<path d="M4 6h5v5H4zM15 6h5v5h-5zM9.5 15h5v5h-5z"/><path d="M9 8.5h6M12 11v4"/>',
        vpn: '<path d="M6 11V8a6 6 0 0 1 12 0v3"/><rect x="4" y="11" width="16" height="9" rx="2"/><path d="M12 14v3"/>',
        security: '<circle cx="12" cy="12" r="8"/><path d="M8 12h8M12 8v8"/>',
        nas: '<rect x="4" y="5" width="16" height="14" rx="2"/><path d="M8 9h8M8 13h8M8 16h.01"/>',
        modem: '<rect x="4" y="8" width="16" height="9" rx="2"/><path d="M8 8V5M12 8V4M16 8V5M8 13h.01M12 13h.01M16 13h.01"/>',
        phone: '<path d="M7 3h4l1 5-3 2a14 14 0 0 0 5 5l2-3 5 1v4c0 1-1 2-2 2C10 19 5 14 5 6c0-2 1-3 2-3z"/>',
        camera: '<path d="M4 8h4l2-2h4l2 2h4v9H4z"/><circle cx="12" cy="12.5" r="3"/>',
        power: '<path d="M12 3v8"/><path d="M7 5.5a8 8 0 1 0 10 0"/>',
        printer: '<path d="M6 9V4h12v5M6 16H4V9h16v7h-2M7 14h10v6H7z"/>',
        other: '<circle cx="12" cy="12" r="8"/><path d="M9 12h6M12 9v6"/>'
    };

    function typeEmoji(type) {
        const map = { switch: '⇄', router: '⌁', server: '▣', vm: '▤', firewall: '◈', ap: '◉', controller: '◌', loadbalancer: '⇆', vpn: '🔐', security: '🛡', nas: '▥', modem: '▰', phone: '☎', camera: '◍', power: 'ϟ', printer: '▧', other: '◆' };
        return map[type?.icon || type?.category] || '◆';
    }

    function typeIconSvg(type, size = 22) {
        const key = type?.icon || type?.category || 'other';
        const body = TYPE_ICON_PATHS[key] || TYPE_ICON_PATHS.other;
        return `<svg class="device-type-icon" width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${body}</svg>`;
    }

    function updateDeviceTypePreview(typeId) {
        const preview = document.getElementById('deviceTypeVisual');
        if (!preview) return;
        const type = DB.getDeviceTypes().find(t => t.id === typeId);
        if (!type) {
            preview.innerHTML = '<span class="preview-placeholder">نوع تجهیز را انتخاب کنید</span>';
            return;
        }
        preview.innerHTML = `${typeIconSvg(type, 30)}<div><strong>${esc(type.name)}</strong><span>شناسه دسته: ${esc(type.category || 'other')}</span></div>`;
    }

    function renderDynamicFields(typeId, targetContainerId = 'dynamicFieldsContainer', existingData = {}) {
        const container = document.getElementById(targetContainerId);
        const types = DB.getDeviceTypes();
        const selectedType = types.find(t => t.id === typeId);

        if (!selectedType) {
            container.innerHTML = '';
            return;
        }

        let html = '';
        const typeName = selectedType.name;

        if (typeName.includes('Cisco') || selectedType.category === 'switch') {
            html = `
                <div class="form-divider full-width">تنظیمات تخصصی سوئیچ / Cisco</div>
                <div class="form-group"><label>سرویس‌ها (Services)</label><input type="text" class="dyn-field" data-key="services" value="${esc(existingData.services)}" placeholder="SSH, HTTPS, SNMP"></div>
                <div class="full-width">
                    <label style="font-weight:bold; margin-bottom: 5px; display:block;">VLANs Dynamic Table</label>
                    <div class="responsive-table"><table class="data-table" id="${targetContainerId}_vlanTable">
                        <thead>
                            <tr><th>VLAN ID</th><th>VLAN Name</th><th>Network</th><th>Gateway</th><th>حذف</th></tr>
                        </thead>
                        <tbody class="vlanRows"></tbody>
                    </table></div>
                    <button type="button" class="btn btn-secondary btn-sm addVlanRowBtn" style="margin-top: 8px;"><span aria-hidden="true">＋</span> افزودن VLAN</button>
                </div>
            `;
        } else if (typeName.includes('MikroTik')) {
            html = `
                <div class="form-divider full-width">تنظیمات اختصاصی MikroTik RouterOS</div>
                <div class="form-group"><label>Identity</label><input type="text" class="dyn-field" data-key="mtIdentity" value="${esc(existingData.mtIdentity)}" placeholder="Router-Main"></div>
                <div class="form-group"><label>Interfaces</label><input type="text" class="dyn-field" data-key="mtInterfaces" value="${esc(existingData.mtInterfaces)}" placeholder="ether1-WAN, ether2-LAN"></div>
                <div class="form-group"><label>IP Addresses</label><input type="text" class="dyn-field" data-key="mtIpAddresses" value="${esc(existingData.mtIpAddresses)}" placeholder="192.168.1.1/24"></div>
                <div class="form-group"><label>Bridge Config</label><input type="text" class="dyn-field" data-key="mtBridges" value="${esc(existingData.mtBridges)}" placeholder="bridge1"></div>
                <div class="form-group"><label>DHCP Server</label><input type="text" class="dyn-field" data-key="mtDhcpServer" value="${esc(existingData.mtDhcpServer)}" placeholder="dhcp1 (pool1)"></div>
                <div class="form-group"><label>NAT Rules</label><input type="text" class="dyn-field" data-key="mtNat" value="${esc(existingData.mtNat)}" placeholder="srcnat masquerade"></div>
                <div class="form-group"><label>Firewall Rules</label><input type="text" class="dyn-field" data-key="mtFirewall" value="${esc(existingData.mtFirewall)}" placeholder="Input drop, Forward accept"></div>
                <div class="form-group"><label>VPN Config</label><input type="text" class="dyn-field" data-key="mtVpn" value="${esc(existingData.mtVpn)}" placeholder="L2TP/IPsec Server Enabled"></div>
                <div class="form-group"><label>DNS & NTP</label><input type="text" class="dyn-field" data-key="mtDnsNtp" value="${esc(existingData.mtDnsNtp)}" placeholder="DNS: 8.8.8.8, NTP: pool.ntp.org"></div>
            `;
        } else if (typeName.includes('Server') || selectedType.category === 'server') {
            html = `
                <div class="form-divider full-width">مشخصات سخت‌افزاری و نرم‌افزاری سرور</div>
                <div class="form-group"><label>سیستم عامل (OS & Version)</label><input type="text" class="dyn-field" data-key="serverOs" value="${esc(existingData.serverOs)}" placeholder="Windows Server 2022 / Ubuntu 22.04"></div>
                <div class="form-group"><label>پردازنده (CPU)</label><input type="text" class="dyn-field" data-key="serverCpu" value="${esc(existingData.serverCpu)}" placeholder="2x Intel Xeon Gold 6248"></div>
                <div class="form-group"><label>حافظه رم (RAM)</label><input type="text" class="dyn-field" data-key="serverRam" value="${esc(existingData.serverRam)}" placeholder="128 GB DDR4 ECC"></div>
                <div class="form-group"><label>فضای ذخیره‌سازی (Storage)</label><input type="text" class="dyn-field" data-key="serverStorage" value="${esc(existingData.serverStorage)}" placeholder="4x 1.92TB NVMe SSD"></div>
                <div class="form-group"><label>پیکربندی RAID</label><input type="text" class="dyn-field" data-key="serverRaid" value="${esc(existingData.serverRaid)}" placeholder="RAID 10 (Hardware Controller)"></div>
                <div class="form-group"><label>Domain / Active Directory</label><input type="text" class="dyn-field" data-key="serverDomain" value="${esc(existingData.serverDomain)}" placeholder="corp.local"></div>
            `;
        } else if (typeName.includes('Virtual') || selectedType.category === 'vm') {
            html = `
                <div class="form-divider full-width">مشخصات ماشین مجازی (Virtual Machine)</div>
                <div class="form-group"><label>Hypervisor / Host</label><input type="text" class="dyn-field" data-key="vmHypervisor" value="${esc(existingData.vmHypervisor)}" placeholder="VMware ESXi 7.0 - Node 01"></div>
                <div class="form-group"><label>سیستم عامل (Guest OS)</label><input type="text" class="dyn-field" data-key="vmOs" value="${esc(existingData.vmOs)}" placeholder="Ubuntu Server 22.04 LTS"></div>
                <div class="form-group"><label>تعداد vCPU</label><input type="text" class="dyn-field" data-key="vmVcpu" value="${esc(existingData.vmVcpu)}" placeholder="8 Cores"></div>
                <div class="form-group"><label>vRAM</label><input type="text" class="dyn-field" data-key="vmVram" value="${esc(existingData.vmVram)}" placeholder="32 GB"></div>
                <div class="form-group"><label>vDisk Storage</label><input type="text" class="dyn-field" data-key="vmStorage" value="${esc(existingData.vmStorage)}" placeholder="250 GB Thin Provisioned"></div>
                <div class="form-group"><label>VLAN / Network PortGroup</label><input type="text" class="dyn-field" data-key="vmVlan" value="${esc(existingData.vmVlan)}" placeholder="VLAN_10_Servers"></div>
            `;
        } else if (selectedType.category === 'ap') {
            html = `
                <div class="form-divider full-width">مشخصات اختصاصی اکسس‌پوینت</div>
                <div class="form-group"><label>کنترلر / مدیریت</label><input type="text" class="dyn-field" data-key="apController" value="${esc(existingData.apController)}" placeholder="Cisco WLC / UniFi / Standalone"></div>
                <div class="form-group"><label>SSID</label><input type="text" class="dyn-field" data-key="apSsid" value="${esc(existingData.apSsid)}" placeholder="Company-WiFi"></div>
                <div class="form-group"><label>استاندارد Wi‑Fi</label><input type="text" class="dyn-field" data-key="apWifi" value="${esc(existingData.apWifi)}" placeholder="Wi‑Fi 6 / 802.11ax"></div>
                <div class="form-group"><label>PoE</label><input type="text" class="dyn-field" data-key="apPoe" value="${esc(existingData.apPoe)}" placeholder="802.3at"></div>`;
        } else if (selectedType.category === 'controller') {
            html = `
                <div class="form-divider full-width">مشخصات کنترلر وایرلس</div>
                <div class="form-group"><label>مدل / Platform</label><input type="text" class="dyn-field" data-key="ctrlPlatform" value="${esc(existingData.ctrlPlatform)}" placeholder="Cisco 9800 / Aruba Central"></div>
                <div class="form-group"><label>تعداد AP مدیریت‌شده</label><input type="number" class="dyn-field" data-key="ctrlAps" value="${esc(existingData.ctrlAps)}" min="0"></div>
                <div class="form-group"><label>High Availability</label><input type="text" class="dyn-field" data-key="ctrlHa" value="${esc(existingData.ctrlHa)}" placeholder="Active/Standby"></div>`;
        } else if (selectedType.category === 'loadbalancer') {
            html = `
                <div class="form-divider full-width">مشخصات Load Balancer</div>
                <div class="form-group"><label>نوع / Vendor</label><input type="text" class="dyn-field" data-key="lbVendor" value="${esc(existingData.lbVendor)}" placeholder="F5 / HAProxy / Citrix"></div>
                <div class="form-group"><label>Virtual IP (VIP)</label><input type="text" class="dyn-field" data-key="lbVip" value="${esc(existingData.lbVip)}" placeholder="10.10.10.100"></div>
                <div class="form-group"><label>Poolها / سرویس‌ها</label><input type="text" class="dyn-field" data-key="lbPools" value="${esc(existingData.lbPools)}" placeholder="WEB-POOL, API-POOL"></div>`;
        } else if (selectedType.category === 'security') {
            html = `
                <div class="form-divider full-width">مشخصات امنیت شبکه</div>
                <div class="form-group"><label>Mode / Engine</label><input type="text" class="dyn-field" data-key="secMode" value="${esc(existingData.secMode)}" placeholder="Inline / TAP"></div>
                <div class="form-group"><label>Signature / Rule Version</label><input type="text" class="dyn-field" data-key="secVersion" value="${esc(existingData.secVersion)}" placeholder="2026.09"></div>
                <div class="form-group"><label>Management Console</label><input type="text" class="dyn-field" data-key="secConsole" value="${esc(existingData.secConsole)}" placeholder="SIEM / Manager"></div>`;
        } else if (selectedType.category === 'nas') {
            html = `
                <div class="form-divider full-width">مشخصات NAS / ذخیره‌سازی</div>
                <div class="form-group"><label>سیستم عامل / Firmware</label><input type="text" class="dyn-field" data-key="nasOs" value="${esc(existingData.nasOs)}" placeholder="Synology DSM / TrueNAS"></div>
                <div class="form-group"><label>ظرفیت</label><input type="text" class="dyn-field" data-key="nasCapacity" value="${esc(existingData.nasCapacity)}" placeholder="40 TB usable"></div>
                <div class="form-group"><label>RAID</label><input type="text" class="dyn-field" data-key="nasRaid" value="${esc(existingData.nasRaid)}" placeholder="RAID 6"></div>
                <div class="form-group"><label>NFS / SMB / iSCSI</label><input type="text" class="dyn-field" data-key="nasProtocols" value="${esc(existingData.nasProtocols)}" placeholder="SMB, NFS, iSCSI"></div>`;
        } else if (selectedType.category === 'modem') {
            html = `
                <div class="form-divider full-width">مشخصات مودم / ONT</div>
                <div class="form-group"><label>نوع لینک</label><input type="text" class="dyn-field" data-key="modemLink" value="${esc(existingData.modemLink)}" placeholder="Fiber / VDSL / LTE"></div>
                <div class="form-group"><label>ISP</label><input type="text" class="dyn-field" data-key="modemIsp" value="${esc(existingData.modemIsp)}" placeholder="نام سرویس‌دهنده"></div>
                <div class="form-group"><label>WAN IP / Public IP</label><input type="text" class="dyn-field" data-key="modemWan" value="${esc(existingData.modemWan)}" placeholder="203.0.113.10"></div>`;
        } else if (selectedType.category === 'phone') {
            html = `
                <div class="form-divider full-width">مشخصات VoIP</div>
                <div class="form-group"><label>Extension</label><input type="text" class="dyn-field" data-key="phoneExt" value="${esc(existingData.phoneExt)}" placeholder="1201"></div>
                <div class="form-group"><label>SIP Server</label><input type="text" class="dyn-field" data-key="phoneSip" value="${esc(existingData.phoneSip)}" placeholder="10.10.10.20"></div>
                <div class="form-group"><label>VLAN Voice</label><input type="text" class="dyn-field" data-key="phoneVlan" value="${esc(existingData.phoneVlan)}" placeholder="30"></div>`;
        } else if (selectedType.category === 'camera') {
            html = `
                <div class="form-divider full-width">مشخصات دوربین / NVR</div>
                <div class="form-group"><label>نوع</label><input type="text" class="dyn-field" data-key="camType" value="${esc(existingData.camType)}" placeholder="IP Camera / NVR"></div>
                <div class="form-group"><label>کانال / تعداد دوربین</label><input type="number" class="dyn-field" data-key="camChannels" value="${esc(existingData.camChannels)}" min="0"></div>
                <div class="form-group"><label>Storage / Retention</label><input type="text" class="dyn-field" data-key="camStorage" value="${esc(existingData.camStorage)}" placeholder="20 TB / 30 days"></div>`;
        } else if (selectedType.category === 'power') {
            html = `
                <div class="form-divider full-width">مشخصات UPS / برق</div>
                <div class="form-group"><label>ظرفیت</label><input type="text" class="dyn-field" data-key="powerCapacity" value="${esc(existingData.powerCapacity)}" placeholder="10 kVA"></div>
                <div class="form-group"><label>زمان پشتیبانی</label><input type="text" class="dyn-field" data-key="powerRuntime" value="${esc(existingData.powerRuntime)}" placeholder="20 min @ 50% load"></div>`;
        } else if (selectedType.category === 'printer') {
            html = `
                <div class="form-divider full-width">مشخصات پرینتر شبکه</div>
                <div class="form-group"><label>Protocol</label><input type="text" class="dyn-field" data-key="printerProtocol" value="${esc(existingData.printerProtocol)}" placeholder="RAW 9100 / LPR / IPP"></div>
                <div class="form-group"><label>Queue / Share Name</label><input type="text" class="dyn-field" data-key="printerQueue" value="${esc(existingData.printerQueue)}" placeholder="PRN-01"></div>`;
        } else {
            html = `<div class="form-divider full-width">اطلاعات اختصاصی ${esc(typeName)}</div>`;
        }

        container.innerHTML = html;

        // Attach event listener for adding dynamic VLAN rows
        const addVlanBtn = container.querySelector('.addVlanRowBtn');
        if (addVlanBtn) {
            addVlanBtn.addEventListener('click', () => {
                const tbody = container.querySelector('.vlanRows');
                appendVlanRow(tbody, {});
            });

            // If existing VLANs exist, render them
            if (existingData.vlans && Array.isArray(existingData.vlans)) {
                const tbody = container.querySelector('.vlanRows');
                existingData.vlans.forEach(v => appendVlanRow(tbody, v));
            }
        }
    }

    function appendVlanRow(tbody, v = {}) {
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td><input type="number" class="vlan-id" value="${v.id || ''}" placeholder="10"></td>
            <td><input type="text" class="vlan-name" value="${v.name || ''}" placeholder="Management"></td>
            <td><input type="text" class="vlan-net" value="${v.net || ''}" placeholder="192.168.10.0/24"></td>
            <td><input type="text" class="vlan-gw" value="${v.gw || ''}" placeholder="192.168.10.1"></td>
            <td><button type="button" class="btn btn-danger btn-sm" onclick="this.closest('tr').remove()"><svg class="inline-action-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M5 7h14M10 11v6M14 11v6M9 4h6l1 3H8l1-3zM7 7l1 14h8l1-14"/></svg></button></td>
        `;
        tbody.appendChild(tr);
    }

    // -------------------------------------------------------------
    // Forms Management & Dynamic Additions
    // -------------------------------------------------------------

    // -------------------------------------------------------------
    // Network field validation / input hardening
    // -------------------------------------------------------------
    function isValidIPv4(value) {
        const s = String(value || '').trim();
        if (!/^\d{1,3}(?:\.\d{1,3}){3}$/.test(s)) return false;
        return s.split('.').every(part => Number(part) >= 0 && Number(part) <= 255);
    }

    function isValidSubnetMask(value) {
        const s = String(value || '').trim();
        if (!isValidIPv4(s)) return false;
        const n = s.split('.').map(Number);
        const bits = n.map(o => o.toString(2).padStart(8, '0')).join('');
        return /^1*0*$/.test(bits);
    }

    function isValidCIDR(value) {
        const s = String(value || '').trim();
        const m = s.match(/^(\d{1,3}(?:\.\d{1,3}){3})\/(\d{1,2})$/);
        return !!m && isValidIPv4(m[1]) && Number(m[2]) >= 0 && Number(m[2]) <= 32;
    }

    function isValidMac(value) {
        const s = String(value || '').trim();
        return /^(?:[0-9A-Fa-f]{2}[:-]){5}[0-9A-Fa-f]{2}$/.test(s);
    }

    function sanitizeIPv4Input(input) {
        const old = input.value;
        let value = old.replace(/[^\d.]/g, '').replace(/\.{2,}/g, '.');
        const parts = value.split('.');
        if (parts.length > 4) value = parts.slice(0, 4).join('.');
        else value = parts.map(p => p.slice(0, 3)).join('.');
        if (input.value !== value) {
            const pos = Math.min(input.selectionStart ?? value.length, value.length);
            input.value = value;
            try { input.setSelectionRange(pos, pos); } catch (_) {}
        }
        return value;
    }

    function sanitizeCIDRInput(input) {
        const old = input.value;
        let value = old.replace(/[^\d./]/g, '').replace(/\.{2,}/g, '.');
        const slash = value.indexOf('/');
        if (slash >= 0) {
            let ip = value.slice(0, slash).split('.').slice(0, 4).map(p => p.slice(0, 3)).join('.');
            let prefix = value.slice(slash + 1).replace(/\D/g, '').slice(0, 2);
            value = ip + '/' + prefix;
        } else {
            value = value.split('.').slice(0, 4).map(p => p.slice(0, 3)).join('.');
        }
        if (input.value !== value) input.value = value;
        return value;
    }

    function sanitizeMacInput(input) {
        const value = input.value.replace(/[^0-9a-fA-F:-]/g, '').slice(0, 17);
        if (input.value !== value) input.value = value;
        return value;
    }

    function markNetworkField(input, valid, message) {
        if (!input) return;
        input.classList.toggle('network-invalid', !valid);
        input.setCustomValidity(valid ? '' : message);
        if (!valid) input.title = message;
        else input.removeAttribute('title');
    }

    function validateNetworkInput(input) {
        if (!input) return true;
        const kind = input.dataset.networkType;
        if (!kind) return true;

        const value = input.value.trim();
        // Empty optional network fields are allowed; required-ness remains
        // controlled by the form itself.
        if (!value) {
            markNetworkField(input, true, '');
            return true;
        }

        let valid = true;
        let message = '';

        if (kind === 'ipv4') {
            sanitizeIPv4Input(input);
            valid = isValidIPv4(input.value);
            message = 'آدرس IPv4 معتبر وارد کنید؛ هر بخش باید بین 0 تا 255 باشد.';
        } else if (kind === 'subnet') {
            sanitizeIPv4Input(input);
            valid = isValidSubnetMask(input.value);
            message = 'Subnet Mask معتبر وارد کنید؛ مانند 255.255.255.0.';
        } else if (kind === 'cidr') {
            sanitizeCIDRInput(input);
            valid = isValidCIDR(input.value);
            message = 'آدرس باید به شکل IPv4/Prefix باشد؛ مانند 192.168.1.1/24.';
        } else if (kind === 'mac') {
            sanitizeMacInput(input);
            valid = isValidMac(input.value);
            message = 'MAC Address معتبر وارد کنید؛ مانند 00:11:22:33:44:55.';
        } else if (kind === 'vlan') {
            input.value = input.value.replace(/\D/g, '').slice(0, 4);
            const n = Number(input.value);
            valid = input.value !== '' && n >= 1 && n <= 4094;
            message = 'VLAN ID باید عددی بین 1 تا 4094 باشد.';
        }

        markNetworkField(input, valid, message);
        return valid;
    }

    function initPortValidation() {
        document.addEventListener('input', (e) => {
            const input = e.target.closest('.ip-port');
            if (!input) return;
            input.value = input.value.replace(/\D/g, '').slice(0, 5);
            const n = Number(input.value);
            input.classList.toggle('network-invalid', input.value !== '' && (n < 1 || n > 65535));
            input.title = input.classList.contains('network-invalid') ? 'پورت باید بین 1 تا 65535 باشد.' : '';
        });
    }

    function initNetworkValidation() {
        // Static fields.
        const mappings = {
            devMgmtIp: 'ipv4',
            devSubnet: 'subnet',
            devGateway: 'ipv4',
            devMac: 'mac',
            editDevMgmtIp: 'ipv4',
            editDevMac: 'mac'
        };
        Object.entries(mappings).forEach(([id, type]) => {
            const input = document.getElementById(id);
            if (input) {
                input.dataset.networkType = type;
                input.setAttribute('inputmode', type === 'mac' ? 'text' : 'decimal');
                input.setAttribute('autocomplete', 'off');
            }
        });

        // Dynamic IP / VLAN fields are handled through event delegation.
        document.addEventListener('input', e => {
            const input = e.target.closest(
                '.ip-address, .ip-subnet, .ip-gateway, .vlan-id, .vlan-net, .vlan-gw, .dyn-field'
            );
            if (!input) return;

            if (input.matches('.ip-address')) input.dataset.networkType = 'ipv4';
            else if (input.matches('.ip-subnet')) input.dataset.networkType = 'subnet';
            else if (input.matches('.ip-gateway')) input.dataset.networkType = 'ipv4';
            else if (input.matches('.vlan-id')) input.dataset.networkType = 'vlan';
            else if (input.matches('.vlan-net')) input.dataset.networkType = 'cidr';
            else if (input.matches('.vlan-gw')) input.dataset.networkType = 'ipv4';
            else {
                const key = input.dataset.key || '';
                if (/^(?:.*)?(?:ip|vip|wan)$/i.test(key) && !/addresses/i.test(key)) {
                    input.dataset.networkType = 'ipv4';
                } else if (/ipaddresses/i.test(key)) {
                    input.dataset.networkType = 'cidr';
                }
            }
            validateNetworkInput(input);
        });

        document.addEventListener('blur', e => {
            const input = e.target.closest('input[data-network-type]');
            if (input) validateNetworkInput(input);
        }, true);

        document.addEventListener('change', e => {
            const input = e.target.closest('input[data-network-type]');
            if (input) validateNetworkInput(input);
        });

        document.querySelectorAll('input[data-network-type]').forEach(validateNetworkInput);
    }

    function validateAllPorts() {
        let valid = true;
        document.querySelectorAll('.ip-port').forEach(input => {
            const value = input.value.trim();
            const ok = value === '' || (/^\d+$/.test(value) && Number(value) >= 1 && Number(value) <= 65535);
            input.classList.toggle('network-invalid', !ok);
            if (!ok) valid = false;
        });
        return valid;
    }

    function validateAllNetworkFields() {
        let valid = true;
        document.querySelectorAll(
            '#deviceForm input[data-network-type], #editFormContainer input[data-network-type], ' +
            '#ipRows input, #editIpRows input, #vlanRows input, #editVlanRows input'
        ).forEach(input => {
            // Assign types to dynamic rows that may have been added after init.
            if (!input.dataset.networkType) {
                if (input.matches('.ip-address')) input.dataset.networkType = 'ipv4';
                else if (input.matches('.ip-subnet')) input.dataset.networkType = 'subnet';
                else if (input.matches('.ip-gateway')) input.dataset.networkType = 'ipv4';
                else if (input.matches('.vlan-id')) input.dataset.networkType = 'vlan';
                else if (input.matches('.vlan-net')) input.dataset.networkType = 'cidr';
                else if (input.matches('.vlan-gw')) input.dataset.networkType = 'ipv4';
            }
            if (input.dataset.networkType && !validateNetworkInput(input)) valid = false;
        });
        return valid;
    }

    function initForms() {
        // Company Create
        document.getElementById('companyForm').addEventListener('submit', (e) => {
            e.preventDefault();
            const company = {
                name: document.getElementById('compName').value,
                location: document.getElementById('compLocation').value,
                description: document.getElementById('compDescription').value
            };
            const savedCompany = DB.saveCompany(company);
            alert('مجموعه جدید با موفقیت ایجاد شد. اکنون می‌توانید تجهیز آن را ثبت کنید.');
            e.target.reset();
            populateSelects();

            // After creating a company, take the user directly to the equipment tab
            // and pre-select the company so the workflow continues without an extra step.
            const createTabBtn = document.querySelector('.tab-btn[data-tab="create-device-tab"]');
            if (createTabBtn) createTabBtn.click();
            const companySelect = document.getElementById('deviceCompanySelect');
            companySelect.value = savedCompany.id;
            document.getElementById('devName')?.focus();
        });

        // Device Type change listener in Create
        const typeSelect = document.getElementById('deviceTypeSelect');
        typeSelect.addEventListener('change', (e) => {
            if (e.target.value === '__NEW__') {
                document.getElementById('deviceTypeModal').style.display = 'flex';
            } else {
                updateDeviceTypePreview(e.target.value);
                renderDynamicFields(e.target.value, 'dynamicFieldsContainer');
            }
        });

        document.getElementById('closeTypeModalBtn').addEventListener('click', () => {
            document.getElementById('deviceTypeModal').style.display = 'none';
            typeSelect.value = '';
            updateDeviceTypePreview('');
        });

        document.getElementById('saveCustomTypeBtn').addEventListener('click', () => {
            const name = document.getElementById('newTypeName').value;
            const category = document.getElementById('newTypeCategory').value;
            if (name) {
                const newType = DB.saveDeviceType({ name: name, category: category, isCustom: true });
                populateSelects();
                typeSelect.value = newType.id;
                updateDeviceTypePreview(newType.id);
                document.getElementById('deviceTypeModal').style.display = 'none';
                renderDynamicFields(newType.id, 'dynamicFieldsContainer');
            }
        });

        // User Accounts Dynamic Rows in Create
        document.getElementById('addUserRowBtn').addEventListener('click', () => {
            appendUserRow(document.getElementById('userRows'), {});
        });

        // IP Addresses Dynamic Rows in Create
        document.getElementById('addIpRowBtn').addEventListener('click', () => {
            appendIpRow(document.getElementById('ipRows'), {});
        });

        // Save Device Form Submit
        document.getElementById('deviceForm').addEventListener('submit', (e) => {
            e.preventDefault();
            if (!validateAllNetworkFields() || !validateAllPorts()) {
                alert('لطفاً مقادیر شبکه را اصلاح کنید. IP، Subnet Mask، Gateway، MAC و VLAN باید معتبر باشند.');
                const firstInvalid = e.target.querySelector('.network-invalid');
                if (firstInvalid) firstInvalid.focus();
                return;
            }
            const deviceData = collectFormData('deviceForm', 'dynamicFieldsContainer', 'userRows', 'ipRows');
            DB.saveDevice(deviceData);
            alert('تجهیز با موفقیت ثبت گردید.');
            e.target.reset();
            document.getElementById('userRows').innerHTML = '';
            document.getElementById('ipRows').innerHTML = '';
            document.getElementById('dynamicFieldsContainer').innerHTML = '';
        });

        // Company Edit
        const companyEditForm = document.getElementById('companyEditForm');
        if (companyEditForm) {
            companyEditForm.addEventListener('submit', (e) => {
                e.preventDefault();
                const id = document.getElementById('editCompanyId').value;
                if (!id) return;
                const updated = DB.updateCompany({
                    id,
                    name: document.getElementById('editCompanyName').value.trim(),
                    location: document.getElementById('editCompanyLocation').value.trim(),
                    description: document.getElementById('editCompanyDescription').value.trim()
                });
                if (!updated) return;
                populateSelects();
                populateEditSelects();
                renderDashboard();
                alert('مشخصات مجموعه با موفقیت به‌روزرسانی شد.');
            });

            const deleteCompanyBtn = document.getElementById('deleteCompanyBtn');
            if (deleteCompanyBtn) {
                deleteCompanyBtn.addEventListener('click', () => {
                    const id = document.getElementById('editCompanyId').value;
                    const company = DB.getCompanies().find(c => c.id === id);
                    if (!company) return;
                    const deviceCount = DB.getDevices().filter(d => d.companyId === id).length;
                    const warning = deviceCount
                        ? `\n\n⚠ با حذف این مجموعه، ${deviceCount} تجهیز ثبت‌شده در آن نیز حذف خواهد شد.`
                        : '';
                    if (!confirm(`آیا از حذف مجموعه «${company.name}» اطمینان دارید؟${warning}\n\nاین عملیات قابل بازگشت نیست.`)) return;

                    const result = DB.deleteCompany(id);
                    if (!result.deleted) return;

                    document.getElementById('editCompanyId').value = '';
                    document.getElementById('editCompanyName').value = '';
                    document.getElementById('editCompanyLocation').value = '';
                    document.getElementById('editCompanyDescription').value = '';
                    document.querySelector('.company-edit-panel')?.classList.remove('has-company');
                    populateSelects();
                    populateEditSelects();
                    document.getElementById('editFormContainer').style.display = 'none';
                    renderDashboard();
                    alert(`مجموعه حذف شد${result.devicesRemoved ? ` و ${result.devicesRemoved} تجهیز وابسته نیز حذف شد` : ''}.`);
                });
            }
        }

        // Settings Database Reset
        document.getElementById('resetDbBtn').addEventListener('click', () => {
            if (confirm('آیا از بازنشانی کلیه داده‌ها به داده‌های اولیه نمونه اطمینان دارید؟')) {
                DB.resetToDefaults();
                alert('پایگاه داده به حالت اولیه بازگشت.');
                location.reload();
            }
        });

        // Full local database export/import
        const exportFullDataBtn = document.getElementById('exportFullDataBtn');
        const importFullDataBtn = document.getElementById('importFullDataBtn');
        const importFullDataInput = document.getElementById('importFullDataInput');
        const importStatus = document.getElementById('importStatus');
        const importHtmlDataBtn = document.getElementById('importHtmlDataBtn');
        const importHtmlDataInput = document.getElementById('importHtmlDataInput');

        if (exportFullDataBtn) {
            exportFullDataBtn.addEventListener('click', () => {
                const backup = DB.exportAll();
                const json = JSON.stringify(backup, null, 2);
                const blob = new Blob([json], { type: 'application/json;charset=utf-8' });
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a');
                const stamp = new Date().toISOString().replace(/[:.]/g, '-');
                a.href = url;
                a.download = `NetDoc-Pro-Full-Backup-${stamp}.json`;
                document.body.appendChild(a);
                a.click();
                a.remove();
                URL.revokeObjectURL(url);
                if (importStatus) importStatus.textContent = `پشتیبان کامل ساخته شد: ${backup.data.companies.length} مجموعه، ${backup.data.devices.length} تجهیز و ${backup.data.deviceTypes.length} نوع تجهیز.`;
            });
        }

        if (importFullDataBtn && importFullDataInput) {
            importFullDataBtn.addEventListener('click', () => importFullDataInput.click());
            importFullDataInput.addEventListener('change', async (e) => {
                const file = e.target.files && e.target.files[0];
                if (!file) return;
                try {
                    const text = await file.text();
                    const payload = JSON.parse(text);
                    DB.validateImport(payload);
                    const counts = payload.data;
                    const ok = confirm(
                        `این فایل شامل ${counts.companies.length} مجموعه، ${counts.devices.length} تجهیز و ${counts.deviceTypes.length} نوع تجهیز است.\n\n` +
                        'مجموعه‌هایی که نامشان در سیستم وجود دارد با اطلاعات فایل جایگزین می‌شوند؛ مجموعه‌های جدید نیز اضافه می‌شوند. ادامه می‌دهید؟'
                    );
                    if (!ok) return;
                    const result = DB.importAll(payload);
                    if (importStatus) importStatus.textContent = `Import انجام شد: ${result.replacedCompanies || 0} مجموعه جایگزین و ${result.addedCompanies || 0} مجموعه جدید اضافه شد؛ ${result.devices} تجهیز و ${result.deviceTypes} نوع تجهیز پردازش شد.`;
                    alert('اطلاعات با موفقیت وارد و بازیابی شد.');
                    populateSelects();
                    populateEditSelects();
                    renderDashboard();
                } catch (err) {
                    if (importStatus) importStatus.textContent = 'خطا: فایل پشتیبان معتبر نیست یا ساختار آن با NetDoc Pro سازگار نیست.';
                    alert('وارد کردن فایل انجام نشد.\n\n' + (err.message || 'فایل نامعتبر است.'));
                } finally {
                    importFullDataInput.value = '';
                }
            });
        }

        // Import a single-company HTML document. Newer exports contain embedded
        // machine-readable JSON; older HTML exports are parsed from their visible tables.
        if (importHtmlDataBtn && importHtmlDataInput) {
            importHtmlDataBtn.addEventListener('click', () => importHtmlDataInput.click());
            importHtmlDataInput.addEventListener('change', async (e) => {
                const file = e.target.files && e.target.files[0];
                if (!file) return;
                try {
                    const html = await file.text();
                    const parsed = parseStandaloneHtmlDocument(html);
                    const ok = confirm(
                        `مجموعه «${parsed.company.name}» با ${parsed.devices.length} تجهیز از فایل HTML شناسایی شد.\n\n` +
                        'اگر نام مجموعه در سیستم وجود داشته باشد، همان مجموعه و تجهیزاتش جایگزین می‌شوند؛ در غیر این صورت مجموعه جدید اضافه می‌شود. ادامه می‌دهید؟'
                    );
                    if (!ok) return;
                    const result = DB.importSingleCompany(parsed.company, parsed.devices, parsed.deviceTypes);
                    if (importStatus) importStatus.textContent = `Import HTML انجام شد: ${result.replacedCompanies || 0} مجموعه جایگزین و ${result.addedCompanies || 0} مجموعه جدید اضافه شد؛ ${result.devices} تجهیز وارد شد.`;
                    alert('مستندات HTML با موفقیت وارد شد.');
                    populateSelects();
                    populateEditSelects();
                    renderDashboard();
                } catch (err) {
                    if (importStatus) importStatus.textContent = 'خطا در Import HTML: ' + (err.message || 'فایل نامعتبر است.');
                    alert('وارد کردن فایل HTML انجام نشد.\n\n' + (err.message || 'فایل نامعتبر است.'));
                } finally {
                    importHtmlDataInput.value = '';
                }
            });
        }
    }

    function parseStandaloneHtmlDocument(html) {
        const parser = new DOMParser();
        const doc = parser.parseFromString(html, 'text/html');
        const embedded = doc.querySelector('script[type="application/json"][id="netdoc-export-data"]');
        if (embedded && embedded.textContent.trim()) {
            const data = JSON.parse(embedded.textContent);
            if (data && data.company && Array.isArray(data.devices)) {
                return {
                    company: data.company,
                    devices: data.devices,
                    deviceTypes: Array.isArray(data.deviceTypes) ? data.deviceTypes : []
                };
            }
        }

        const h1 = doc.querySelector('.header h1, h1');
        const titleText = (h1?.textContent || '').replace(/^مجموعه\s*:\s*/i, '').trim();
        if (!titleText) throw new Error('نام مجموعه از فایل HTML قابل تشخیص نیست.');
        const headerP = doc.querySelector('.header p');
        const locationMatch = (headerP?.textContent || '').match(/موقعیت:\s*([^|]+)/);
        const company = { id: 'html_company', name: titleText, location: locationMatch ? locationMatch[1].trim() : '', description: '' };
        const devices = [];
        const deviceTypes = [];
        const typeByName = new Map();

        const textAfterLabel = (el) => {
            const clone = el.cloneNode(true);
            const label = clone.querySelector('.info-label');
            if (label) label.remove();
            return clone.textContent.trim();
        };
        const clean = (v) => String(v || '').replace(/\s+/g, ' ').trim();
        const ensureType = (name) => {
            const key = clean(name).toLowerCase() || 'other';
            if (!typeByName.has(key)) {
                const id = 'html_t_' + typeByName.size + '_' + Date.now();
                const type = { id, name: clean(name) || 'Other', category: 'other', icon: 'other' };
                typeByName.set(key, type);
                deviceTypes.push(type);
            }
            return typeByName.get(key);
        };

        doc.querySelectorAll('.device-card').forEach((card, index) => {
            const title = clean(card.querySelector('.device-title')?.textContent) || `Imported Device ${index + 1}`;
            const typeName = clean(card.querySelector('.device-type-badge')?.textContent) || 'Other';
            const type = ensureType(typeName);
            const d = { id: 'html_d_' + Date.now() + '_' + index, companyId: company.id, deviceTypeId: type.id, name: title, users: [], ipAddresses: [], vlans: [] };
            card.querySelectorAll('.info-item').forEach(item => {
                const label = clean(item.querySelector('.info-label')?.textContent).replace(/:$/, '');
                const value = clean(textAfterLabel(item));
                const map = {
                    'نام میزبان': 'hostname', 'مدل': 'model', 'برند': 'brand',
                    'موقعیت/رک': 'rack', 'IP مدیریت': 'managementIp',
                    'ماسک شبکه': 'subnetMask', 'درگاه': 'gateway', 'آدرس MAC': 'macAddress'
                };
                if (map[label]) d[map[label]] = value === '-' ? '' : value;
            });
            card.querySelectorAll('table').forEach(table => {
                const headers = Array.from(table.querySelectorAll('thead th')).map(th => clean(th.textContent));
                const rows = Array.from(table.querySelectorAll('tbody tr'));
                if (headers.includes('نام کاربری')) {
                    d.users = rows.map(tr => { const c=Array.from(tr.children).map(x=>clean(x.textContent)); return {username:c[0]||'', password:clean(tr.querySelector('.real-pwd')?.textContent)||'', role:c[2]||'', notes:c[3]||''}; });
                } else if (headers.includes('آدرس IP')) {
                    d.ipAddresses = rows.map(tr => { const c=Array.from(tr.children).map(x=>clean(x.textContent)); return {interface:c[0]||'', protocol:c[1]||'', port:c[2]||'', address:c[3]||'', subnet:c[4]||'', gateway:c[5]||'', notes:c[6]||''}; });
                } else if (headers.includes('VLAN ID')) {
                    d.vlans = rows.map(tr => { const c=Array.from(tr.children).map(x=>clean(x.textContent)); return {id:Number(c[0])||0, name:c[1]||'', net:c[2]||'', gw:c[3]||''}; });
                }
            });
            const note = card.querySelector('.info-item') ? null : null;
            const noteText = Array.from(card.querySelectorAll('div')).find(el => /یادداشت‌ها/.test(el.textContent || '') && !el.querySelector('table'));
            if (noteText) d.notes = clean(noteText.textContent).replace(/^یادداشت‌ها\s*:\s*/,'');
            devices.push(d);
        });
        if (!devices.length) throw new Error('هیچ تجهیز قابل تشخیصی در فایل HTML پیدا نشد.');
        return { company, devices, deviceTypes };
    }

    function appendUserRow(tbody, u = {}) {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td><input type="text" class="user-username" value="${esc(u.username)}" placeholder="مدیر شبکه"></td>
            <td>
                <div class="password-field">
                    <input type="password" class="user-password" value="${esc(u.password)}" placeholder="رمز عبور">
                    <button type="button" class="icon-btn toggle-password" title="نمایش رمز عبور" aria-label="نمایش رمز عبور" aria-pressed="false"><svg class="eye-icon eye-open" viewBox="0 0 24 24" aria-hidden="true"><path d="M2.5 12s3.4-6 9.5-6 9.5 6 9.5 6-3.4 6-9.5 6-9.5-6-9.5-6z"/><circle cx="12" cy="12" r="2.5"/></svg><svg class="eye-icon eye-closed" viewBox="0 0 24 24" aria-hidden="true"><path d="M3 3l18 18M9.9 5.2A10.8 10.8 0 0 1 12 5c6.1 0 9.5 7 9.5 7a17 17 0 0 1-3.1 3.9M6.2 6.2C3.8 7.8 2.5 12 2.5 12s3.4 6 9.5 6c1.1 0 2.1-.2 3.1-.5"/></svg></button>
                </div>
            </td>
            <td><input type="text" class="user-role" value="${esc(u.role)}" placeholder="مدیر"></td>
            <td><input type="text" class="user-notes" value="${esc(u.notes)}" placeholder="توضیحات دسترسی"></td>
            <td><button type="button" class="btn btn-danger btn-sm" title="حذف کاربر" aria-label="حذف کاربر" onclick="this.closest('tr').remove()"><svg class="inline-action-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M5 7h14M10 11v6M14 11v6M9 4h6l1 3H8l1-3zM7 7l1 14h8l1-14"/></svg></button></td>
        `;
        tbody.appendChild(row);
    }

    function appendIpRow(tbody, ip = {}) {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td><input type="text" class="ip-interface" value="${esc(ip.interface)}" placeholder="مثال: ether1 / WAN / Vlan10"></td>
            <td><input type="text" class="ip-protocol" value="${esc(ip.protocol || '')}" placeholder="مثال: SSH / HTTP / SNMP"></td>
            <td><input type="text" class="ip-port" inputmode="numeric" autocomplete="off" maxlength="5" value="${esc(ip.port ?? '')}" placeholder="مثال: 3333" pattern="[0-9]{1,5}"></td>
            <td><input type="text" class="ip-address" data-network-type="ipv4" inputmode="decimal" autocomplete="off" maxlength="15" value="${esc(ip.address)}" placeholder="192.168.1.1"></td>
            <td><input type="text" class="ip-subnet" data-network-type="subnet" inputmode="decimal" autocomplete="off" maxlength="15" value="${esc(ip.subnet)}" placeholder="255.255.255.0"></td>
            <td><input type="text" class="ip-gateway" data-network-type="ipv4" inputmode="decimal" autocomplete="off" maxlength="15" value="${esc(ip.gateway)}" placeholder="192.168.1.1"></td>
            <td><input type="text" class="ip-notes" value="${esc(ip.notes)}" placeholder="توضیحات"></td>
            <td><button type="button" class="btn btn-danger btn-sm" title="حذف IP" aria-label="حذف IP" onclick="this.closest('tr').remove()"><svg class="inline-action-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M5 7h14M10 11v6M14 11v6M9 4h6l1 3H8l1-3zM7 7l1 14h8l1-14"/></svg></button></td>
        `;
        tbody.appendChild(row);
    }

    function collectFormData(formId, dynamicContainerId, userRowsId, ipRowsId) {
        const users = [];
        document.querySelectorAll(`#${userRowsId} tr`).forEach(r => {
            users.push({
                username: r.querySelector('.user-username').value,
                password: r.querySelector('.user-password').value,
                role: r.querySelector('.user-role').value,
                notes: r.querySelector('.user-notes').value
            });
        });

        const ipAddresses = [];
        if (ipRowsId) {
            document.querySelectorAll(`#${ipRowsId} tr`).forEach(r => {
                ipAddresses.push({
                    interface: r.querySelector('.ip-interface').value,
                    protocol: r.querySelector('.ip-protocol').value,
                    port: r.querySelector('.ip-port').value,
                    address: r.querySelector('.ip-address').value,
                    subnet: r.querySelector('.ip-subnet').value,
                    gateway: r.querySelector('.ip-gateway').value,
                    notes: r.querySelector('.ip-notes').value
                });
            });
        }

        const dynObj = {};
        document.querySelectorAll(`#${dynamicContainerId} .dyn-field`).forEach(input => {
            const key = input.getAttribute('data-key');
            dynObj[key] = input.value;
        });

        // Collect VLANs if present
        const vlans = [];
        document.querySelectorAll(`#${dynamicContainerId} .vlanRows tr`).forEach(vr => {
            vlans.push({
                id: vr.querySelector('.vlan-id').value,
                name: vr.querySelector('.vlan-name').value,
                net: vr.querySelector('.vlan-net').value,
                gw: vr.querySelector('.vlan-gw').value
            });
        });

        return {
            companyId: document.getElementById('deviceCompanySelect').value,
            deviceTypeId: document.getElementById('deviceTypeSelect').value,
            name: document.getElementById('devName').value,
            hostname: document.getElementById('devHostname').value,
            brand: document.getElementById('devBrand').value,
            model: document.getElementById('devModel').value,
            rack: document.getElementById('devRack').value,
            managementIp: document.getElementById('devMgmtIp').value,
            subnetMask: document.getElementById('devSubnet').value,
            gateway: document.getElementById('devGateway').value,
            macAddress: document.getElementById('devMac').value,
            notes: document.getElementById('devNotes').value,
            users: users,
            vlans: vlans,
            ipAddresses: ipAddresses,
            ...dynObj
        };
    }

    // -------------------------------------------------------------
    // Edit & Update View Logic
    // -------------------------------------------------------------
    function populateEditSelects() {
        const editCompSelect = document.getElementById('editCompanySelect');
        const companies = DB.getCompanies();

        editCompSelect.innerHTML = '<option value="">انتخاب شرکت یا کارخانه...</option>';
        companies.forEach(c => {
            editCompSelect.innerHTML += `<option value="${c.id}">${c.name}</option>`;
        });

        editCompSelect.onchange = (e) => {
            const companyId = e.target.value;
            loadCompanyIntoEditForm(companyId);
            const editDevSelect = document.getElementById('editDeviceSelect');
            if (!companyId) {
                editDevSelect.disabled = true;
                editDevSelect.innerHTML = '<option value="">ابتدا مجموعه را انتخاب کنید...</option>';
                return;
            }

            const devices = DB.getDevices().filter(d => d.companyId === companyId);
            editDevSelect.disabled = false;
            editDevSelect.innerHTML = '<option value="">انتخاب تجهیز برای ویرایش...</option>';
            devices.forEach(d => {
                editDevSelect.innerHTML += `<option value="${d.id}">${d.name} (${d.model || 'No Model'})</option>`;
            });
        };

        const editDevSelect = document.getElementById('editDeviceSelect');
        editDevSelect.onchange = (e) => {
            const devId = e.target.value;
            if (!devId) {
                document.getElementById('editFormContainer').style.display = 'none';
                return;
            }
            loadDeviceIntoEditForm(devId);
        };
    }

    function loadCompanyIntoEditForm(companyId) {
        const company = DB.getCompanies().find(c => c.id === companyId);
        const panel = document.querySelector('.company-edit-panel');
        if (!panel) return;
        if (!company) {
            panel.classList.remove('has-company');
            document.getElementById('editCompanyId').value = '';
            document.getElementById('editCompanyName').value = '';
            document.getElementById('editCompanyLocation').value = '';
            document.getElementById('editCompanyDescription').value = '';
            const deleteCompanyBtn = document.getElementById('deleteCompanyBtn');
            if (deleteCompanyBtn) deleteCompanyBtn.disabled = true;
            return;
        }
        panel.classList.add('has-company');
        const deleteCompanyBtn = document.getElementById('deleteCompanyBtn');
        if (deleteCompanyBtn) deleteCompanyBtn.disabled = false;
        document.getElementById('editCompanyId').value = company.id;
        document.getElementById('editCompanyName').value = company.name || '';
        document.getElementById('editCompanyLocation').value = company.location || '';
        document.getElementById('editCompanyDescription').value = company.description || '';
    }

    function openCompanyForEdit(companyId) {
        const editNav = document.querySelector('[data-target="edit"]');
        if (editNav) editNav.click();
        const select = document.getElementById('editCompanySelect');
        if (!select) return;
        select.value = companyId;
        select.dispatchEvent(new Event('change'));
        document.querySelector('.company-edit-panel')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }

    function openDeviceForEdit(deviceId) {
        const device = DB.getDevices().find(d => d.id === deviceId);
        if (!device) return;

        const editNav = document.querySelector('[data-target="edit"]');
        if (editNav) editNav.click();

        const companySelect = document.getElementById('editCompanySelect');
        const deviceSelect = document.getElementById('editDeviceSelect');
        if (!companySelect || !deviceSelect) return;

        companySelect.value = device.companyId;
        companySelect.dispatchEvent(new Event('change'));
        deviceSelect.value = device.id;
        deviceSelect.dispatchEvent(new Event('change'));
        document.getElementById('editFormContainer')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }

    function initCompanyLinks() {
        document.addEventListener('click', (e) => {
            const deviceLink = e.target.closest('[data-device-link]');
            if (deviceLink) {
                e.preventDefault();
                openDeviceForEdit(deviceLink.getAttribute('data-device-link'));
                return;
            }
            const link = e.target.closest('[data-company-link]');
            if (!link) return;
            e.preventDefault();
            openCompanyForEdit(link.getAttribute('data-company-link'));
        });
    }

    function loadDeviceIntoEditForm(devId) {
        const dev = DB.getDevices().find(d => d.id === devId);
        if (!dev) return;

        document.getElementById('editFormContainer').style.display = 'block';
        document.getElementById('editDevName').value = dev.name || '';
        document.getElementById('editDevHostname').value = dev.hostname || '';
        document.getElementById('editDevBrand').value = dev.brand || '';
        document.getElementById('editDevModel').value = dev.model || '';
        document.getElementById('editDevRack').value = dev.rack || '';
        document.getElementById('editDevMgmtIp').value = dev.managementIp || '';
        document.getElementById('editDevNotes').value = dev.notes || '';

        // Render dynamic fields with existing values
        renderDynamicFields(dev.deviceTypeId, 'editDynamicFieldsContainer', dev);

        // Load Users
        const editUserRows = document.getElementById('editUserRows');
        editUserRows.innerHTML = '';
        if (dev.users && Array.isArray(dev.users)) {
            dev.users.forEach(u => appendUserRow(editUserRows, u));
        }

        document.getElementById('addEditUserRowBtn').onclick = () => {
            appendUserRow(editUserRows, {});
        };

        // Load IP Addresses
        const editIpRows = document.getElementById('editIpRows');
        editIpRows.innerHTML = '';
        if (dev.ipAddresses && Array.isArray(dev.ipAddresses)) {
            dev.ipAddresses.forEach(ip => appendIpRow(editIpRows, ip));
        }

        document.getElementById('addEditIpRowBtn').onclick = () => {
            appendIpRow(editIpRows, {});
        };

        // Form Submit for Update
        document.getElementById('editDeviceForm').onsubmit = (e) => {
            e.preventDefault();
            if (!validateAllNetworkFields() || !validateAllPorts()) {
                alert('لطفاً مقادیر شبکه را اصلاح کنید. IP، Subnet Mask، Gateway، MAC و VLAN باید معتبر باشند.');
                const firstInvalid = document.querySelector('.network-invalid');
                if (firstInvalid) firstInvalid.focus();
                return;
            }

            const updatedUsers = [];
            document.querySelectorAll('#editUserRows tr').forEach(r => {
                updatedUsers.push({
                    username: r.querySelector('.user-username').value,
                    password: r.querySelector('.user-password').value,
                    role: r.querySelector('.user-role').value,
                    notes: r.querySelector('.user-notes').value
                });
            });

            const dynObj = {};
            document.querySelectorAll('#editDynamicFieldsContainer .dyn-field').forEach(input => {
                const key = input.getAttribute('data-key');
                dynObj[key] = input.value;
            });

            const vlans = [];
            document.querySelectorAll('#editDynamicFieldsContainer .vlanRows tr').forEach(vr => {
                vlans.push({
                    id: vr.querySelector('.vlan-id').value,
                    name: vr.querySelector('.vlan-name').value,
                    net: vr.querySelector('.vlan-net').value,
                    gw: vr.querySelector('.vlan-gw').value
                });
            });

            const updatedIpAddresses = [];
            document.querySelectorAll('#editIpRows tr').forEach(r => {
                updatedIpAddresses.push({
                    interface: r.querySelector('.ip-interface').value,
                    protocol: r.querySelector('.ip-protocol').value,
                    port: r.querySelector('.ip-port').value,
                    address: r.querySelector('.ip-address').value,
                    subnet: r.querySelector('.ip-subnet').value,
                    gateway: r.querySelector('.ip-gateway').value,
                    notes: r.querySelector('.ip-notes').value
                });
            });

            const updatedDevice = {
                id: dev.id,
                companyId: dev.companyId,
                deviceTypeId: dev.deviceTypeId,
                name: document.getElementById('editDevName').value,
                hostname: document.getElementById('editDevHostname').value,
                brand: document.getElementById('editDevBrand').value,
                model: document.getElementById('editDevModel').value,
                rack: document.getElementById('editDevRack').value,
                managementIp: document.getElementById('editDevMgmtIp').value,
                notes: document.getElementById('editDevNotes').value,
                users: updatedUsers,
                vlans: vlans,
                ipAddresses: updatedIpAddresses,
                ...dynObj
            };

            DB.saveDevice(updatedDevice);
            alert('اطلاعات تجهیز با موفقیت به‌روزرسانی شد.');
        };

        document.getElementById('deleteDeviceBtn').onclick = () => {
            if (confirm(`آیا از حذف تجهیز ${dev.name} اطمینان دارید؟`)) {
                DB.deleteDevice(dev.id);
                alert('تجهیز حذف شد.');
                document.getElementById('editFormContainer').style.display = 'none';
                populateEditSelects();
            }
        };
    }

    // -------------------------------------------------------------
    // Dashboard Rendering
    // -------------------------------------------------------------
    function renderDashboard() {
        const companies = DB.getCompanies();
        const devices = DB.getDevices();
        const types = DB.getDeviceTypes();

        document.getElementById('totalCompanies').innerText = companies.length;
        document.getElementById('totalDevices').innerText = devices.length;

        let servers = 0, switches = 0, routers = 0, vms = 0;
        devices.forEach(d => {
            const t = types.find(type => type.id === d.deviceTypeId);
            if (t) {
                if (t.name.includes('Server') || t.category === 'server') servers++;
                if (t.name.includes('Switch') || t.category === 'switch') switches++;
                if (t.name.includes('Router') || t.category === 'router') routers++;
                if (t.name.includes('Virtual') || t.category === 'vm') vms++;
            }
        });

        document.getElementById('totalServers').innerText = servers;
        document.getElementById('totalSwitches').innerText = switches;
        document.getElementById('totalRouters').innerText = routers;
        document.getElementById('totalVMs').innerText = vms;

        renderCollectionsList(document.getElementById('globalSearch').value.trim().toLowerCase());
    }

    // -------------------------------------------------------------
    // Dashboard collection list
    // -------------------------------------------------------------
    function renderCollectionsList(searchQuery = '') {
        let container;
        try {
        container = document.getElementById('projectsContainer');
        const companies = Array.isArray(DB.getCompanies()) ? DB.getCompanies() : [];
        const devices = Array.isArray(DB.getDevices()) ? DB.getDevices() : [];
        const types = Array.isArray(DB.getDeviceTypes()) ? DB.getDeviceTypes() : [];
        if (!container) return;
        container.innerHTML = '';

        const visibleCompanies = companies
            .slice()
            .sort((a, b) => new Date(b.updatedAt || 0) - new Date(a.updatedAt || 0));

        visibleCompanies.forEach(c => {
            const compDevices = devices.filter(d => d.companyId === c.id);

            if (searchQuery) {
                const hasMatchingDevice = compDevices.some(d => {
                    const matchName = d.name && d.name.toLowerCase().includes(searchQuery);
                    const matchHost = d.hostname && d.hostname.toLowerCase().includes(searchQuery);
                    const matchIp = d.managementIp && d.managementIp.toLowerCase().includes(searchQuery);
                    const matchExtraIp = d.ipAddresses && d.ipAddresses.some(ip => ip.address && ip.address.toLowerCase().includes(searchQuery));
                    const matchModel = d.model && d.model.toLowerCase().includes(searchQuery);
                    const matchUsers = d.users && d.users.some(u => u.username && u.username.toLowerCase().includes(searchQuery));
                    const matchCompName = c.name && c.name.toLowerCase().includes(searchQuery);

                    return matchName || matchHost || matchIp || matchExtraIp || matchModel || matchUsers || matchCompName;
                });

                if (!hasMatchingDevice && !String(c.name || '').toLowerCase().includes(searchQuery)) return;
            }

            const updatedDate = c.updatedAt ? new Date(c.updatedAt).toLocaleDateString('fa-IR') : 'نامشخص';
            const devicesHtml = compDevices.map(d => {
                const type = types.find(t => t.id === d.deviceTypeId);
                return `
                    <div class="device-subcard">
                        <div class="device-subcard-header">
                            <button type="button" class="device-name-line device-link" data-device-link="${esc(d.id)}">${typeIconSvg(type, 22)} <span>${esc(d.name || 'بدون نام')}</span></button>
                            <small style="color: var(--accent-blue);">${esc(type ? type.name : 'نامشخص')}</small>
                        </div>
                        <div class="device-card-details">
                            <div><strong>IP:</strong> <span>${esc(d.managementIp || 'نامشخص')}</span></div>
                            <div><strong>مدل:</strong> ${esc(d.model || '-')}</div>
                            <div><strong>موقعیت:</strong> ${esc(d.rack || 'ثبت نشده')}</div>
                            ${d.ipAddresses && d.ipAddresses.filter(ip => ip.address).length ? `<div><strong>IPهای دیگر:</strong> ${esc(d.ipAddresses.filter(ip => ip.address).map(ip => ip.address).join('، '))}</div>` : ''}
                        </div>
                    </div>`;
            }).join('');

            container.innerHTML += `
                <article class="site-card collection-card">
                    <div class="site-header">
                        <div class="site-title">
                            <h2 class="site-title-line"><button type="button" class="company-link company-link-large" data-company-link="${esc(c.id)}">${typeIconSvg({icon:'building'}, 23)}<span>${esc(c.name || 'بدون نام')}</span></button></h2>
                            <small>${esc(c.location || 'بدون موقعیت جغرافیا')}</small>
                        </div>
                        <div class="collection-card-meta">
                            <span class="badge collection-device-count">${compDevices.length} تجهیز</span>
                            <small>تاریخ تغییر: ${updatedDate}</small>
                        </div>
                    </div>
                    <div class="site-devices-grid">
                        ${devicesHtml || '<p class="no-device-message">هنوز تجهیزی برای این مجموعه ثبت نشده است.</p>'}
                    </div>
                </article>
            `;
        });

        if (container.innerHTML === '') {
            container.innerHTML = '<p class="collection-list-empty">هیچ مجموعه‌ای مطابق با جستجوی شما یافت نشد.</p>';
        }
        } catch (error) {
            if (!container) return;
            const companies = Array.isArray(DB.getCompanies()) ? DB.getCompanies() : [];
            container.innerHTML = companies.map(c => `
                <article class="site-card collection-card">
                    <h2 class="site-title-line"><button type="button" class="company-link company-link-large" data-company-link="${esc(c.id)}">${esc(c.name || 'بدون نام')}</button></h2>
                    <small>${esc(c.location || 'ثبت نشده')}</small>
                </article>`).join('') || '<p class="collection-list-empty">هیچ مجموعه‌ای ثبت نشده است.</p>';
            console.error('Collection list fallback used:', error);
        }
    }

    // -------------------------------------------------------------
    // Standalone HTML Export Logic
    // -------------------------------------------------------------
    function renderExportOptions() {
        const btn = document.getElementById('generateExportBtn');
        btn.onclick = () => {
            const companyId = document.getElementById('exportCompanySelect').value;
            if (!companyId) {
                alert('لطفاً یک مجموعه را انتخاب کنید.');
                return;
            }

            const company = DB.getCompanies().find(c => c.id === companyId);
            const devices = DB.getDevices().filter(d => d.companyId === companyId);
            const types = DB.getDeviceTypes();

            const fullHtml = generateStandaloneExportHtml(company, devices, types);

            document.getElementById('exportPreviewArea').style.display = 'block';
            document.getElementById('exportHtmlCode').value = fullHtml;

            // Copy Action
            document.getElementById('copyHtmlCodeBtn').onclick = () => {
                navigator.clipboard.writeText(fullHtml);
                alert('کد HTML خروجی با موفقیت در حافظه (Clipboard) کپی شد.');
            };

            // Download Action
            document.getElementById('downloadHtmlFileBtn').onclick = () => {
                const blob = new Blob([fullHtml], { type: 'text/html;charset=utf-8' });
                const link = document.createElement('a');
                link.href = URL.createObjectURL(blob);
                link.download = `NetDoc_${company.name.replace(/\s+/g, '_')}_Documentation.html`;
                link.click();
            };
        };
    }

    function generateStandaloneExportHtml(company, devices, types) {
        let devBlocks = '';

        devices.forEach(d => {
            const t = types.find(type => type.id === d.deviceTypeId);
            const typeName = t ? t.name : 'Unknown Device';

            // Build Users Table
            let usersTableHtml = '';
            if (d.users && d.users.length > 0) {
                let userRows = '';
                d.users.forEach(u => {
                    const safePassword = String(u.password || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#039;');
                    userRows += `
                        <tr>
                            <td><strong>${u.username || '-'}</strong></td>
                            <td class="sensitive-pwd">
                                <span class="pwd-text">••••••••</span>
                                <span class="real-pwd" style="display:none;">${safePassword}</span>
                                <button type="button" class="copy-btn password-export-toggle" data-password="${safePassword}" title="نمایش رمز عبور">👁 نمایش / کپی</button>
                            </td>
                            <td>${u.role || '-'}</td>
                            <td>${u.notes || '-'}</td>
                        </tr>
                    `;
                });
                usersTableHtml = `
                    <div class="section-subtitle">حساب‌های کاربری</div>
                    <table>
                        <thead>
                            <tr><th>نام کاربری</th><th>رمز عبور</th><th>نقش کاربر</th><th>توضیحات</th></tr>
                        </thead>
                        <tbody>${userRows}</tbody>
                    </table>
                `;
            }

            // Build IP Addresses Table
            let ipTableHtml = '';
            const validIps = (d.ipAddresses || []).filter(ip => ip.address);
            if (validIps.length > 0) {
                let ipRows = '';
                validIps.forEach(ip => {
                    ipRows += `<tr><td>${ip.interface || '-'}</td><td>${ip.protocol || '-'}</td><td>${ip.port || '-'}</td><td>${ip.address || '-'}</td><td>${ip.subnet || '-'}</td><td>${ip.gateway || '-'}</td><td>${ip.notes || '-'}</td></tr>`;
                });
                ipTableHtml = `
                    <div class="section-subtitle">آدرس‌های IP (چند اینترفیسه)</div>
                    <table>
                        <thead>
                            <tr><th>اینترفیس / برچسب</th><th>پروتکل</th><th>پورت</th><th>آدرس IP</th><th>Subnet Mask</th><th>Gateway</th><th>توضیحات</th></tr>
                        </thead>
                        <tbody>${ipRows}</tbody>
                    </table>
                `;
            }

            // Build VLANs Table
            let vlansTableHtml = '';
            if (d.vlans && d.vlans.length > 0) {
                let vlanRows = '';
                d.vlans.forEach(v => {
                    vlanRows += `<tr><td>${v.id}</td><td>${v.name}</td><td>${v.net}</td><td>${v.gw}</td></tr>`;
                });
                vlansTableHtml = `
                    <div class="section-subtitle">تنظیمات VLANs</div>
                    <table>
                        <thead>
                            <tr><th>VLAN ID</th><th>نام VLAN</th><th>شبکه (Subnet)</th><th>Gateway</th></tr>
                        </thead>
                        <tbody>${vlanRows}</tbody>
                    </table>
                `;
            }

            devBlocks += `
                <div class="device-card">
                    <div class="device-header">
                        <div>
                            <span class="device-title">${d.name}</span>
                            <span class="device-type-badge">${typeName}</span>
                        </div>
                        <button class="copy-btn" onclick="copyText('${d.managementIp}')">کپی Management IP (${d.managementIp})</button>
                    </div>

                    <div class="info-grid">
                        <div class="info-item"><span class="info-label">نام میزبان:</span> ${d.hostname || '-'}</div>
                        <div class="info-item"><span class="info-label">مدل:</span> ${d.model || '-'}</div>
                        <div class="info-item"><span class="info-label">برند:</span> ${d.brand || '-'}</div>
                        <div class="info-item"><span class="info-label">موقعیت/رک:</span> ${d.rack || '-'}</div>
                        <div class="info-item"><span class="info-label">IP مدیریت:</span> ${d.managementIp || '-'}</div>
                        <div class="info-item"><span class="info-label">ماسک شبکه:</span> ${d.subnetMask || '-'}</div>
                        <div class="info-item"><span class="info-label">درگاه:</span> ${d.gateway || '-'}</div>
                        <div class="info-item"><span class="info-label">آدرس MAC:</span> ${d.macAddress || '-'}</div>
                    </div>

                    ${ipTableHtml}
                    ${vlansTableHtml}
                    ${usersTableHtml}

                    ${d.notes ? `<div style="margin-top: 10px; font-size: 13px; color: #94a3b8;"><strong>یادداشت‌ها:</strong> ${d.notes}</div>` : ''}
                </div>
            `;
        });

        const exportData = JSON.stringify({ company, devices, deviceTypes: types }).replace(/</g, '\u003c');

        return `<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>مستندات شبکه - ${company.name}</title>
    <style>
        :root {
            --bg: #0f172a;
            --card-bg: #1e293b;
            --border: #334155;
            --text: #f8fafc;
            --text-muted: #94a3b8;
            --accent: #38bdf8;
            --accent-green: #4ade80;
        }
        body { font-family: system-ui, -apple-system, sans-serif; background: var(--bg); color: var(--text); padding: 30px; direction: rtl; }
        .header { border-bottom: 2px solid var(--border); padding-bottom: 15px; margin-bottom: 30px; }
        .header h1 { color: var(--accent); margin-bottom: 5px; }
        .device-card { background: var(--card-bg); border: 1px solid var(--border); border-radius: 8px; padding: 20px; margin-bottom: 25px; }
        .device-header { display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid var(--border); padding-bottom: 10px; margin-bottom: 15px; }
        .device-title { font-size: 20px; font-weight: bold; color: var(--accent-green); }
        .device-type-badge { background: rgba(56, 189, 248, 0.2); color: var(--accent); padding: 3px 8px; border-radius: 4px; font-size: 12px; margin-right: 10px; }
        .info-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 10px; margin-bottom: 15px; }
        .info-item { font-size: 13px; }
        .info-label { color: var(--text-muted); font-weight: bold; }
        .section-subtitle { font-size: 14px; font-weight: bold; color: var(--accent); margin: 15px 0 8px 0; border-bottom: 1px dashed var(--border); padding-bottom: 4px; }
        table { width: 100%; border-collapse: collapse; margin-top: 8px; font-size: 13px; }
        th, td { border: 1px solid var(--border); padding: 8px 12px; text-align: right; }
        th { background: #0f172a; color: var(--accent); }
        .copy-btn { background: var(--border); color: var(--text); border: none; padding: 4px 10px; border-radius: 4px; cursor: pointer; font-size: 12px; }
        .copy-btn:hover { background: var(--accent); color: #000; }
    </style>
</head>
<body>
    <div class="header">
        <h1>مجموعه: ${company.name}</h1>
        <p><strong>موقعیت:</strong> ${company.location || 'ثبت نشده'} | <strong>تاریخ تولید خروجی:</strong> ${new Date().toLocaleDateString('fa-IR')}</p>
        <p style="color: var(--text-muted); margin-top: 5px;">${company.description || '-'}</p>
    </div>

    <h2>لیست تجهیزات شبکه (${devices.length})</h2>
    ${devBlocks}

    <script>
        function copyText(text) {
            navigator.clipboard.writeText(text);
            alert('عبارت "' + text + '" کپی شد.');
        }
        document.querySelectorAll('.password-export-toggle').forEach(function(btn) {
            btn.addEventListener('click', function() {
                const parent = btn.parentElement;
                const pwdText = parent.querySelector('.pwd-text');
                const realPwd = parent.querySelector('.real-pwd');
                const showing = realPwd.style.display !== 'none';
                realPwd.style.display = showing ? 'none' : 'inline';
                pwdText.style.display = showing ? 'inline' : 'none';
                btn.textContent = showing ? '👁 نمایش / کپی' : '🙈 مخفی / کپی';
                btn.title = showing ? 'نمایش رمز عبور' : 'مخفی کردن رمز عبور';
                navigator.clipboard.writeText(btn.dataset.password || '');
            });
        });
    </script>
</body>
</html>`;
    }
});
