# NetDoc Pro v1.2.0

نسخه سبک و محلی برای مستندسازی زیرساخت شبکه.

## اجرا
فایل `index.html` را در مرورگر باز کنید. نیاز به سرور یا اینترنت ندارد.

## فناوری
HTML + CSS + JavaScript معمولی + localStorage

## تمرکز v1.2.0
- تم کاملاً تیره و نزدیک به مشکی
- منوی دسکتاپ در سمت راست
- آیکن‌های محلی و بدون وابستگی به CDN
- افزایش قابل توجه انواع تجهیزات شبکه
- فیلدهای اختصاصی اولیه برای تجهیزات جدید
- مهاجرت امن انواع تجهیزات جدید بدون حذف داده‌های قبلی

## فایل‌های نسخه
- `PROMPT-v1.2.0.txt`
- `CHANGELOG-v1.2.0.md`
- `ROADMAP.md`


## v1.2.1

- Responsive hardening across the entire UI, including account/VLAN tables and narrow screens.
- New company edit panel and direct navigation from dashboard/project company names.
- After creating a company, the workflow automatically moves to the “افزودن تجهیز” tab and preselects the new company.
- Local SVG device icons are used throughout the UI; no external icon/CDN dependency is required.
- Added an in-form device type visual preview.
- Password visibility uses a proper local eye/eye-off SVG control.

## v1.2.2

- صفحه مستقل «مجموعه‌ها و اخیر» حذف شد.
- فهرست مجموعه‌ها، جستجو و فیلتر تجهیزات آن به بخش «آخرین مجموعه‌های تغییر یافته» در داشبورد منتقل شد.
- مجموعه‌ها در داشبورد بر اساس آخرین تغییر مرتب هستند و نام هر مجموعه همچنان به ویرایش همان مجموعه می‌رود.
- فایل‌های `PROMPT-v1.2.2.txt` و `CHANGELOG-v1.2.2.md` همراه نسخه هستند.

## v1.2.3

- متن راهنما و فیلترهای دسته‌بندی از بخش «آخرین مجموعه‌های تغییر یافته» حذف شدند.
- کارت‌های پروژه/مجموعه مستقیم زیر عنوان داشبورد نمایش داده می‌شوند.

## v1.2.4

- فهرست داشبورد به شکل ردیفی و فشرده، مطابق نمونه ارائه‌شده، نمایش داده می‌شود.
- عنوان بخش به «مجموعه‌ها» تغییر کرد و کلیک روی نام هر مجموعه وارد ویرایش همان مجموعه می‌شود.

## v1.2.5

- هر کارخانه/مجموعه در داشبورد داخل یک کارت مستقل نمایش داده می‌شود.
- تجهیزات متعلق به همان مجموعه داخل کارت و زیر نام آن نمایش داده می‌شوند.
