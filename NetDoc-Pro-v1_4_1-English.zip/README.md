# NetDoc Pro v1.4.1 — English Edition

An offline, browser-based network documentation and equipment inventory application.

## Sign-in
- Username: `m`
- Password: `admin`

Change the default password after signing in. This local-only login is a convenience feature, not server-grade authentication.

## Run
Extract the ZIP archive and open `index.html` in a modern browser. Application data is stored in the browser local storage. Back up your data before clearing browser storage or moving to another computer.

## Features
- Site and company inventory
- Device registration and editing
- Multiple IP interfaces and user accounts per device
- Network field validation
- HTML documentation export
- Full JSON backup and restore
- Single-site HTML import
- User management
