# NetDoc Pro v1.4.1 — English Edition

- Translated the application interface, forms, tables, dialogs, validation messages, and generated HTML documentation into English.
- Changed the interface layout to left-to-right (LTR).
- Changed date display to English locale.
- Preserved the v1.4.1 login initialization fix and existing data features.
- HTML import recognizes English labels and retains support for older Persian exports.
